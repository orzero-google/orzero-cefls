-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2013 年 01 月 02 日 10:26
-- 服务器版本: 5.5.25a
-- PHP 版本: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `cefls`
--

-- --------------------------------------------------------

--
-- 表的结构 `blog_ads`
--

DROP TABLE IF EXISTS `blog_ads`;
CREATE TABLE IF NOT EXISTS `blog_ads` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text,
  `img` varchar(255) NOT NULL,
  `url` char(255) NOT NULL,
  `cid` tinyint(2) NOT NULL DEFAULT '0',
  `type` tinyint(2) NOT NULL DEFAULT '0',
  `order` int(4) NOT NULL DEFAULT '0',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- 转存表中的数据 `blog_ads`
--

INSERT INTO `blog_ads` (`aid`, `title`, `content`, `img`, `url`, `cid`, `type`, `order`, `enabled`) VALUES
(1, '成都外国语学校', NULL, '/images/temp/93e40500b246d0f6db0d4a7437aaab02.jpg', 'http://www.jsj.com', 0, -1, 0, 1),
(2, 'dafasdfasdfasdf', NULL, '/images/temp/a0d51471bcb57d44fbd17eda772cc06d.jpg', '/images/temp/a0d51471bcb57d44fbd17eda772cc06d.jpg', -1, -3, 0, 1),
(3, 'asdfasdfasdf', NULL, '/images/temp/0e8f18bffa4f8256d81b987cc80787de.jpg', '/images/temp/0e8f18bffa4f8256d81b987cc80787de.jpg', -1, -3, 0, 1),
(4, 'asdfasdf', NULL, '/images/temp/08c38b229a07557fd0fe1c05e4affe88.jpg', 'http://www.baidu.com', 0, 5, 0, 1),
(5, 'asdfasdf', NULL, '/images/temp/6b9afc9c9fd8c8a299a6c2336e0cce57.jpg', 'http://www.baidu.com', 0, 62, 0, 1),
(6, 'ddd', NULL, '', 'http://www.baidu.com', 0, -6, 0, 1),
(7, '哈尔滨工业大学(www.haerbinggydx.com)', '       天体学领域有很多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。州大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。', '/images/temp/13fa4a2d242d081ef413fb9a15e0482a.jpg', 'http://www.baidu.com', 6, 0, 0, 1),
(8, '哈尔滨工业大学(www.haerbinggydx.com)', ' 天体学领域有很多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。州大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。\r\n\r\n', '/images/temp/3384ff9ae960ae7c24b26dd4691636f6.jpg', 'http://www.baidu.com', 6, 0, 0, 1),
(9, '哈尔滨工业大学(www.haerbinggydx.com)', ' 天体学领域有很多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。州大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。\r\n\r\n', '/images/temp/3c65729aaef06c286018c11ef264c766.jpg', 'http://www.baidu.com', 6, 0, 0, 1),
(10, '哈尔滨工业大学(www.haerbinggydx.com)', ' 天体学领域有很多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。州大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。\r\n\r\n', '/images/temp/efebb32b6d094a6c46e6c5831ad321e6.jpg', 'http://www.baidu.com', 6, 0, 0, 1),
(11, '哈尔滨工业大学(www.haerbinggydx.com)', ' 天体学领域有很多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。州大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。\r\n\r\n', '/images/temp/46bb74c311429d23a4545a295e3cea7e.jpg', 'http://www.baidu.com', 6, 0, 0, 1),
(12, '温瑞征', NULL, '/images/temp/690d088f2e4ef5d6d69e877321781dfb.jpg', 'http://www.baidu.com', 0, -7, 0, 1),
(13, '李佳', NULL, '/images/xzfc/1a89aded92a0ba85acf94e494a5c6ac4.jpg', '2012四川省高考文科状元', 50, -10, 0, 0),
(14, '王军', NULL, '/images/xzfc/f69907a068ca3434973b4372dc8558fc.jpg', '2012四川省高考文科状元', 50, -10, 0, 1),
(15, '王军2', NULL, '/images/xzfc/0b5641a75f8072bac58928a4710f393a.jpg', '2012四川省高考文科状元2', 50, -10, 0, 1),
(16, 'xxxx', NULL, '/images/temp/6a31a16a69b19a7f381c53fee30f765d.jpg', 'http://www.baidu.com', 0, 1, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `blog_article`
--

DROP TABLE IF EXISTS `blog_article`;
CREATE TABLE IF NOT EXISTS `blog_article` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `src` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `from` varchar(255) DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `cid` int(2) NOT NULL,
  `audit` tinyint(2) NOT NULL,
  `grade` tinyint(1) NOT NULL,
  `createtime` datetime NOT NULL,
  `updatetime` datetime NOT NULL,
  `title` text NOT NULL,
  `excerpt` text NOT NULL,
  `content` longtext NOT NULL,
  `author` varchar(64) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `sort` int(8) NOT NULL,
  `type` smallint(2) NOT NULL,
  `clicknumber` int(8) DEFAULT '0',
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- 转存表中的数据 `blog_article`
--

INSERT INTO `blog_article` (`aid`, `src`, `file`, `from`, `uid`, `cid`, `audit`, `grade`, `createtime`, `updatetime`, `title`, `excerpt`, `content`, `author`, `enabled`, `sort`, `type`, `clicknumber`) VALUES
(1, NULL, NULL, NULL, 1, 16, 1, 0, '2013-01-11 00:00:00', '2012-12-12 04:16:59', 'xxx', 'bbb', 'asdfasdf', NULL, 1, 0, 0, 0),
(2, NULL, NULL, 'asdfas', 1, -1, 1, 0, '2012-12-12 05:13:45', '2012-12-12 05:25:38', 'xxx', '', '<p>ddasfaasdfasdf</p>', 'asdfa', 1, 0, 0, 0),
(3, NULL, NULL, '管理员', 1, -1, 1, 0, '2012-12-13 02:46:34', '2012-12-13 05:45:39', '大事纪要', '', '<p>撒旦法士大夫</p>', '管理员', 1, 0, 0, 28),
(4, NULL, NULL, '成都市实验外国语学校', 1, -1, 1, 0, '2012-12-18 13:13:29', '2012-12-18 13:13:29', '校长寄语', ' 温瑞征，成都市实验外国语学校创始人 “四川省教育风云人物”，成都市优秀 学校长，成都市优秀教育工作者，一位 著教育四十余年的..... ', '<p>温瑞征，成都市实验外国语学校创始人 &ldquo;四川省教育风云人物&rdquo;，成都市优秀 学校长，成都市优秀教育工作者，一位 著教育四十余年的..... 温瑞征，成都市实验外国语学校创始人 &ldquo;四川省教育风云人物&rdquo;，成都市优秀 学校长，成都市优秀教育工作者，一位 著教育四十余年的..... 温瑞征，成都市实验外国语学校创始人 &ldquo;四川省教育风云人物&rdquo;，成都市优秀 学校长，成都市优秀教育工作者，一位 著教育四十余年的..... 温瑞征，成都市实验外国语学校创始人 &ldquo;四川省教育风云人物&rdquo;，成都市优秀 学校长，成都市优秀教育工作者，一位 著教育四十余年的..... 温瑞征，成都市实验外国语学校创始人 &ldquo;四川省教育风云人物&rdquo;，成都市优秀 学校长，成都市优秀教育工作者，一位 著教育四十余年的.....</p>', '温瑞征', 1, 0, 0, 3),
(5, NULL, NULL, '高中录取分数线', 1, -1, 1, 0, '2012-12-18 13:52:09', '2012-12-18 13:52:09', '公示公告', '一、我校初中毕业学生录取线93分及以上，奖学金线在学校查询；二、非本校初中毕业生660分及以上（免交学费）；三、凡上线生报名时间为6月29日下午和6月30日上午11点30分前，过期不再录取。成都市实验外国语学校2012年6月29日 ', '<p>一、我校初中毕业学生录取线93分及以上，奖学金线在学校查询；二、非本校初中毕业生660分及以上（免交学费）；三、凡上线生报名时间为6月29日下午和6月30日上午11点30分前，过期不再录取。成都市实验外国语学校2012年6月29日</p>\r\n<p>&nbsp;</p>\r\n<p>一、我校初中毕业学生录取线93分及以上，奖学金线在学校查询；二、非本校初中毕业生660分及以上（免交学费）；三、凡上线生报名时间为6月29日下午和6月30日上午11点30分前，过期不再录取。成都市实验外国语学校2012年6月29日</p>\r\n<p>&nbsp;</p>\r\n<p>一、我校初中毕业学生录取线93分及以上，奖学金线在学校查询；二、非本校初中毕业生660分及以上（免交学费）；三、凡上线生报名时间为6月29日下午和6月30日上午11点30分前，过期不再录取。成都市实验外国语学校2012年6月29日 一、我校初中毕业学生录取线93分及以上，奖学金线在学校查询；二、非本校初中毕业生660分及以上（免交学费）；三、凡上线生报名时间为6月29日下午和6月30日上午11点30分前，过期不再录取。成都市实验外国语学校2012年6月29日</p>', '温瑞征', 1, 0, 0, 3),
(6, NULL, NULL, '成都市实验外国语学校', 1, 68, 1, 0, '2012-12-18 13:59:50', '2012-12-18 13:59:50', '高中录取分数线', '一、我校初中毕业学生录取线93分及以上，奖学金线在学校查询；二、非本校初中毕业生660分及以上（免交学费）；三、凡上线生报名时间为6月29日下午和6月30日上午11点30分前，过期不再录取。成都市实验外国语学校2012年6月29日 ', '<p>一、我校初中毕业学生录取线93分及以上，奖学金线在学校查询；二、非本校初中毕业生660分及以上（免交学费）；三、凡上线生报名时间为6月29日下午和6月30日上午11点30分前，过期不再录取。成都市实验外国语学校2012年6月29日 一、我校初中毕业学生录取线93分及以上，奖学金线在学校查询；二、非本校初中毕业生660分及以上（免交学费）；三、凡上线生报名时间为6月29日下午和6月30日上午11点30分前，过期不再录取。成都市实验外国语学校2012年6月29日</p>', '温瑞征', 1, 0, 0, 0),
(7, NULL, '/images/jsdw/7a283f910d4ac1e20152d5b91e7d4d03.jpg', NULL, 1, 18, 0, 0, '2012-12-26 16:30:53', '2012-12-27 16:42:49', 'asdf', '', '<p class="teacherDetail" style="margin: 0px 10px 5px 0px; padding: 0px 0px 0px 10px; width: 775px; font-size: 18px; border: 0px; overflow: hidden; color: #797979; height: auto; line-height: 32px; text-align: left; text-indent: 36px; font-family: ''Bitstream Charter'', serif, 宋体; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff;">2003年3月，朱镕基正式从国务院总位退休。退休正式从国务院总位退时间都闭门谢客在家读书，不再于公众场合露面。他最,式从国务院总位退不在其位，不谋其政。他甚至还常以&ldquo;一介草民&rdquo;幽默,式从国务院总位退固定在北京居住。他去过上海，去过湖南，也去过广东,式从国务院总位退些地方官员礼节性地来访时，快人快语的朱镕基总是开,式从国务院总位退们发现，退休前后的朱镕基判若两人：退休前，他是个,式从国务院总位退他去过上海，去过湖南，也去过广东。但无些地方官员,式从国务院总位退地来访时，快人快语的朱镕基总是开门见山们发现，退,式从国务院总位退的朱镕基判若两人：退休前，他是个公认的,式从国务院总位退目光，以及他做事果断、大刀阔斧、雷厉风行，又 以及他做事果断、大刀阔斧、雷厉风行，但喜欢同普通人聊天。他看书、练书法、拉胡琴。兴致 以及他做事果断、大刀阔斧、雷厉风行，地来一段京戏。过去的严厉与严肃渐渐淡去，面相温和 以及他做事果断、大刀阔斧、雷厉风行，去医院看眼、看牙时，其人到哪里，笑声就跟到哪里， 以及他做事果断、大刀阔斧、雷厉风行，经常乐成了一团&hellip;&hellip;</p>', 'sdaf', 1, 0, -2, 9),
(8, NULL, NULL, '百度', 1, -1, 1, 0, '2012-12-27 15:58:55', '2012-12-27 15:58:55', '联系我们', '联系我们', '<p><a href="http://cefls/index.php/cate/index?pid=1&amp;cid=17">联系我们</a></p>', '李佳', 1, 0, 0, 2),
(9, NULL, NULL, '百度', 1, -1, 1, 0, '2013-01-02 10:06:22', '2013-01-02 10:06:22', '领导班子', '领导班子', '<div class="middle">\r\n<div class="imginfo"><img src="http://cefls/cefls/images/7.jpg" alt="自坐骑山东省内你的设计是的卡速度快 地方借东风的冲v风格刚刚好" />\r\n<p>自坐骑山东省内你的设计是的卡速度快 地方借东风的冲v风格刚刚好</p>\r\n</div>\r\n<div class="imglist">\r\n<div class="imgitem"><a href="#"><img src="http://cefls/cefls/images/8.jpg" alt="" /></a>\r\n<p><a href="#">副校长：某某某</a></p>\r\n</div>\r\n<div class="imgitem"><a href="#"><img src="http://cefls/cefls/images/8.jpg" alt="" /></a>\r\n<p><a href="#">副校长：某某某</a></p>\r\n</div>\r\n<div class="imgitem"><a href="#"><img src="http://cefls/cefls/images/8.jpg" alt="" /></a>\r\n<p><a href="#">副校长：某某某</a></p>\r\n</div>\r\n<div class="imgitem"><a href="#"><img src="http://cefls/cefls/images/8.jpg" alt="" /></a>\r\n<p><a href="#">副校长：某某某</a></p>\r\n</div>\r\n<div class="imgitem"><a href="#"><img src="http://cefls/cefls/images/8.jpg" alt="" /></a>\r\n<p><a href="#">副校长：某某某</a></p>\r\n</div>\r\n</div>\r\n</div>', '李佳', 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `blog_article_foreign`
--

DROP TABLE IF EXISTS `blog_article_foreign`;
CREATE TABLE IF NOT EXISTS `blog_article_foreign` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `cid` int(2) NOT NULL,
  `audit` tinyint(2) NOT NULL,
  `grade` tinyint(1) NOT NULL,
  `createtime` datetime NOT NULL,
  `updatetime` datetime NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `sort` int(8) NOT NULL,
  `type` smallint(2) NOT NULL,
  `title_en` text NOT NULL,
  `excerpt_en` text NOT NULL,
  `content_en` longtext NOT NULL,
  `author_en` varchar(64) DEFAULT NULL,
  `src_en` varchar(255) DEFAULT NULL,
  `file_en` varchar(255) DEFAULT NULL,
  `from_en` varchar(255) DEFAULT NULL,
  `clicknumber_en` int(8) DEFAULT '0',
  `title_fr` text NOT NULL,
  `excerpt_fr` text NOT NULL,
  `content_fr` longtext NOT NULL,
  `author_fr` varchar(64) DEFAULT NULL,
  `src_fr` varchar(255) DEFAULT NULL,
  `file_fr` varchar(255) DEFAULT NULL,
  `from_fr` varchar(255) DEFAULT NULL,
  `clicknumber_fr` int(8) DEFAULT '0',
  `title_de` text NOT NULL,
  `excerpt_de` text NOT NULL,
  `content_de` longtext NOT NULL,
  `author_de` varchar(64) DEFAULT NULL,
  `src_de` varchar(255) DEFAULT NULL,
  `file_de` varchar(255) DEFAULT NULL,
  `from_de` varchar(255) DEFAULT NULL,
  `clicknumber_de` int(8) DEFAULT '0',
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `blog_article_foreign`
--

INSERT INTO `blog_article_foreign` (`aid`, `uid`, `cid`, `audit`, `grade`, `createtime`, `updatetime`, `enabled`, `sort`, `type`, `title_en`, `excerpt_en`, `content_en`, `author_en`, `src_en`, `file_en`, `from_en`, `clicknumber_en`, `title_fr`, `excerpt_fr`, `content_fr`, `author_fr`, `src_fr`, `file_fr`, `from_fr`, `clicknumber_fr`, `title_de`, `excerpt_de`, `content_de`, `author_de`, `src_de`, `file_de`, `from_de`, `clicknumber_de`) VALUES
(1, 1, 0, 1, 0, '2012-12-14 17:04:03', '2012-12-14 17:04:03', 1, 0, 0, 'asdf', 'asdf', '<p>asdf</p>', 'asdf', NULL, NULL, 'asdf', 2, 'asdf', 'asdf', '<p>asdfasdf</p>', 'asdf', NULL, NULL, 'asdf', 0, 'asdfasdf', 'asdfasf', '<p>asdfasdf</p>', 'asdfasdf', NULL, NULL, 'asdfasdf', 0),
(2, 1, 0, 1, 0, '2012-12-14 17:08:12', '2012-12-14 17:08:12', 1, 0, 0, 'asdf', 'dfasdfas', '<p>fasdfasdf</p>', 'fasdfas', NULL, NULL, 'asdfasd', 4, 'asdfasdf', 'fasdf', '<p>afsdasdf</p>', 'fasdfa', NULL, NULL, 'afsdads', 0, 'asdfasdf', 'asdfasdf', '<p>afsdfasdf</p>', 'afdasdf', NULL, NULL, 'asfdasdf', 0);

-- --------------------------------------------------------

--
-- 表的结构 `blog_authassignment`
--

DROP TABLE IF EXISTS `blog_authassignment`;
CREATE TABLE IF NOT EXISTS `blog_authassignment` (
  `itemname` varchar(64) NOT NULL,
  `userid` varchar(64) NOT NULL,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`itemname`,`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `blog_authassignment`
--

INSERT INTO `blog_authassignment` (`itemname`, `userid`, `bizrule`, `data`) VALUES
('Admin', '1', NULL, 'N;'),
('Authenticated', '2', NULL, 'N;');

-- --------------------------------------------------------

--
-- 表的结构 `blog_authitem`
--

DROP TABLE IF EXISTS `blog_authitem`;
CREATE TABLE IF NOT EXISTS `blog_authitem` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `blog_authitem`
--

INSERT INTO `blog_authitem` (`name`, `type`, `description`, `bizrule`, `data`) VALUES
('Admin', 2, NULL, NULL, 'N;'),
('Authenticated', 2, 'Authenticated user', NULL, 'N;'),
('Comment.*', 1, 'Access all comment actions', NULL, 'N;'),
('Comment.Approve', 0, 'Approve comments', NULL, 'N;'),
('Comment.Delete', 0, 'Delete comments', NULL, 'N;'),
('Comment.Update', 0, 'Update comments', NULL, 'N;'),
('CommentAdministration', 1, 'Administration of comments', NULL, 'N;'),
('Editor', 2, 'Editor', NULL, 'N;'),
('Guest', 2, 'Guest user', NULL, 'N;'),
('Post.*', 1, 'Access all post actions', NULL, 'N;'),
('Post.Admin', 0, 'Administer posts', NULL, 'N;'),
('Post.Create', 0, 'Create posts', NULL, 'N;'),
('Post.Delete', 0, 'Delete posts', NULL, 'N;'),
('Post.Update', 0, 'Update posts', NULL, 'N;'),
('Post.View', 0, 'View posts', NULL, 'N;'),
('PostAdministrator', 1, 'Administration of posts', NULL, 'N;'),
('PostUpdateOwn', 0, 'Update own posts', 'return Yii::app()->user->id==$params["userid"];', 'N;');

-- --------------------------------------------------------

--
-- 表的结构 `blog_authitemchild`
--

DROP TABLE IF EXISTS `blog_authitemchild`;
CREATE TABLE IF NOT EXISTS `blog_authitemchild` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `blog_authitemchild`
--

INSERT INTO `blog_authitemchild` (`parent`, `child`) VALUES
('Editor', 'Authenticated'),
('CommentAdministration', 'Comment.*'),
('Editor', 'CommentAdministration'),
('Authenticated', 'CommentUpdateOwn'),
('Authenticated', 'Guest'),
('PostAdministrator', 'Post.*'),
('PostAdministrator', 'Post.Admin'),
('Authenticated', 'Post.Create'),
('PostAdministrator', 'Post.Create'),
('PostAdministrator', 'Post.Delete'),
('PostAdministrator', 'Post.Update'),
('Guest', 'Post.View'),
('Editor', 'PostAdministrator'),
('Authenticated', 'PostUpdateOwn');

-- --------------------------------------------------------

--
-- 表的结构 `blog_comment`
--

DROP TABLE IF EXISTS `blog_comment`;
CREATE TABLE IF NOT EXISTS `blog_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `status` int(11) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `author` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `url` varchar(128) DEFAULT NULL,
  `post_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_comment_post` (`post_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `blog_comment`
--

INSERT INTO `blog_comment` (`id`, `content`, `status`, `create_time`, `author`, `email`, `url`, `post_id`) VALUES
(1, 'This is a test comment.', 2, 1230952187, 'Tester', 'tester@example.com', NULL, 2);

-- --------------------------------------------------------

--
-- 表的结构 `blog_lookup`
--

DROP TABLE IF EXISTS `blog_lookup`;
CREATE TABLE IF NOT EXISTS `blog_lookup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `code` int(11) NOT NULL,
  `type` varchar(128) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `blog_lookup`
--

INSERT INTO `blog_lookup` (`id`, `name`, `code`, `type`, `position`) VALUES
(1, 'Draft', 1, 'PostStatus', 1),
(2, 'Published', 2, 'PostStatus', 2),
(3, 'Archived', 3, 'PostStatus', 3),
(4, 'Pending Approval', 1, 'CommentStatus', 1),
(5, 'Approved', 2, 'CommentStatus', 2);

-- --------------------------------------------------------

--
-- 表的结构 `blog_menu`
--

DROP TABLE IF EXISTS `blog_menu`;
CREATE TABLE IF NOT EXISTS `blog_menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `menu_name` varchar(255) NOT NULL,
  `menu_type` smallint(3) NOT NULL DEFAULT '0',
  `menu_sort` int(4) NOT NULL DEFAULT '0',
  `menu_count` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=69 ;

--
-- 转存表中的数据 `blog_menu`
--

INSERT INTO `blog_menu` (`menu_id`, `parent_id`, `menu_name`, `menu_type`, `menu_sort`, `menu_count`) VALUES
(1, 0, '关于实外', 1, 0, 0),
(2, 0, '师资队伍', 1, 0, 0),
(3, 0, '德育视窗', 1, 0, 0),
(4, 0, '教学科研', 1, 0, 0),
(5, 0, '外语特色', 1, 0, 0),
(6, 0, '交流合作', 1, 0, 0),
(7, 0, '学子风采', 1, 0, 0),
(8, 0, '艺体天地', 1, 0, 0),
(9, 0, '感悟实外', 1, 0, 0),
(10, 1, '实外概况', 2, 0, 0),
(11, 1, '实外文化', 2, 0, 0),
(12, 1, '领导班子', 2, 0, 0),
(13, 1, '组织结构', 2, 0, 0),
(14, 1, '媒体关注', 2, 0, 0),
(15, 1, '资证荣誉', 2, 0, 0),
(16, 1, '大事纪要', 2, 0, 0),
(17, 1, '联系我们', 2, 0, 0),
(18, 2, '数学教师', 2, 0, 0),
(19, 2, '语文教师', 2, 0, 0),
(20, 2, '外语教师', 2, 0, 0),
(21, 2, '物理教师', 2, 0, 0),
(22, 2, '化学教师', 2, 0, 0),
(23, 2, '政治教师', 2, 0, 0),
(24, 2, '历史教师', 2, 0, 0),
(25, 2, '地理教师', 2, 0, 0),
(26, 2, '艺体教师', 2, 0, 0),
(27, 2, '生理卫生教师', 2, 0, 0),
(28, 2, '信息技术教师', 2, 0, 0),
(29, 3, '德育管理', 2, 0, 0),
(30, 3, '德育动态', 2, 0, 0),
(31, 3, '团队活动', 2, 0, 0),
(32, 3, '心理教育', 2, 0, 0),
(33, 3, '德育成果', 2, 0, 0),
(34, 4, '学研管理', 2, 0, 0),
(35, 4, '教学动态', 2, 0, 0),
(36, 4, '教研活动', 2, 0, 0),
(37, 4, '课堂延伸', 2, 0, 0),
(38, 4, '教学成果', 2, 0, 0),
(39, 5, '英语课堂', 2, 0, 0),
(40, 5, '外教风采', 2, 0, 0),
(41, 5, '活动集锦', 2, 0, 0),
(42, 5, '法德苑地', 2, 0, 0),
(43, 5, '外语佳作', 2, 0, 0),
(44, 5, '赛事风云', 2, 0, 0),
(45, 5, '学习资源', 2, 0, 0),
(46, 6, '友好学校', 2, 0, 0),
(47, 6, '国内互动', 2, 0, 0),
(48, 6, '国际往来', 2, 0, 0),
(49, 6, '合作项目', 2, 0, 0),
(50, 7, '状元金榜', 2, 0, 0),
(51, 7, '理科精英', 2, 0, 0),
(52, 7, '文科翘楚', 2, 0, 0),
(53, 7, '高考年报', 2, 0, 0),
(54, 8, '运动时空', 2, 0, 0),
(55, 8, '音乐之声', 2, 0, 0),
(56, 8, '美术佳苑', 2, 0, 0),
(57, 9, '学子寄情', 2, 0, 0),
(58, 9, '家长抒怀', 2, 0, 0),
(59, 9, '教师达意', 2, 0, 0),
(60, 9, '媒评舆论', 2, 0, 0),
(61, 0, '实外信箱', -1, 0, 0),
(62, 43, '英语佳作', 3, 0, 0),
(63, 43, '法语佳作', 3, 0, 0),
(64, 43, '德语佳作', 3, 0, 0),
(65, 1, '友情学校', 2, 0, 0),
(66, 0, '校园快讯', -1, 0, 0),
(67, 0, '校长寄语', -1, 0, 0),
(68, 0, '公示公告', -1, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `blog_post`
--

DROP TABLE IF EXISTS `blog_post`;
CREATE TABLE IF NOT EXISTS `blog_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `content` text NOT NULL,
  `tags` text,
  `status` int(11) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `author_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_post_author` (`author_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `blog_post`
--

INSERT INTO `blog_post` (`id`, `title`, `content`, `tags`, `status`, `create_time`, `update_time`, `author_id`) VALUES
(1, 'Welcome!', 'This blog system is developed using Yii. It is meant to demonstrate how to use Yii to build a complete real-world application. Complete source code may be found in the Yii releases.\r\n\r\nFeel free to try this system by writing new posts and posting comments.', 'yii, blog', 2, 1230952187, 1230952187, 1),
(2, 'A Test Post', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'test', 2, 1230952187, 1230952187, 1),
(3, '阿萨德发生', ' 阿萨德发生的', '2saf', 2, 1354176366, 1354176366, 1);

-- --------------------------------------------------------

--
-- 表的结构 `blog_rights`
--

DROP TABLE IF EXISTS `blog_rights`;
CREATE TABLE IF NOT EXISTS `blog_rights` (
  `itemname` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`itemname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `blog_rights`
--

INSERT INTO `blog_rights` (`itemname`, `type`, `weight`) VALUES
('Authenticated', 2, 1),
('Editor', 2, 0),
('Guest', 2, 2);

-- --------------------------------------------------------

--
-- 表的结构 `blog_tag`
--

DROP TABLE IF EXISTS `blog_tag`;
CREATE TABLE IF NOT EXISTS `blog_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `frequency` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `blog_tag`
--

INSERT INTO `blog_tag` (`id`, `name`, `frequency`) VALUES
(1, 'yii', 1),
(2, 'blog', 1),
(3, 'test', 1),
(4, '2saf', 1);

-- --------------------------------------------------------

--
-- 表的结构 `blog_user`
--

DROP TABLE IF EXISTS `blog_user`;
CREATE TABLE IF NOT EXISTS `blog_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `salt` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `profile` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `blog_user`
--

INSERT INTO `blog_user` (`id`, `username`, `password`, `salt`, `email`, `profile`) VALUES
(1, 'admin', '9401b8c7297832c567ae922cc596a4dd', '28b206548469ce62182048fd9cf91760', 'webmaster@example.com', NULL),
(2, 'demo', '2e5c7db760a33498023813489cfadc0b', '28b206548469ce62182048fd9cf91760', 'webmaster@example.com', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `tbl_article`
--

DROP TABLE IF EXISTS `tbl_article`;
CREATE TABLE IF NOT EXISTS `tbl_article` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `src` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `from` varchar(255) DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `cid` int(2) NOT NULL,
  `audit` tinyint(2) NOT NULL,
  `grade` tinyint(1) NOT NULL,
  `createtime` datetime NOT NULL,
  `updatetime` datetime NOT NULL,
  `title` text NOT NULL,
  `excerpt` text NOT NULL,
  `content` longtext NOT NULL,
  `author` varchar(64) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `sort` int(8) NOT NULL,
  `type` smallint(2) NOT NULL,
  `clicknumber` int(8) DEFAULT '0',
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `tbl_migration`
--

DROP TABLE IF EXISTS `tbl_migration`;
CREATE TABLE IF NOT EXISTS `tbl_migration` (
  `version` varchar(255) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `tbl_migration`
--

INSERT INTO `tbl_migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1353059126),
('m110805_153437_installYiiUser', 1353059159),
('m110810_162301_userTimestampFix', 1353059159);

-- --------------------------------------------------------

--
-- 表的结构 `tbl_profiles`
--

DROP TABLE IF EXISTS `tbl_profiles`;
CREATE TABLE IF NOT EXISTS `tbl_profiles` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `tbl_profiles`
--

INSERT INTO `tbl_profiles` (`user_id`, `first_name`, `last_name`) VALUES
(1, 'Administrator', 'Admin'),
(2, 'xami', 'orzero'),
(3, 'xami', '520');

-- --------------------------------------------------------

--
-- 表的结构 `tbl_profiles_fields`
--

DROP TABLE IF EXISTS `tbl_profiles_fields`;
CREATE TABLE IF NOT EXISTS `tbl_profiles_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `field_type` varchar(50) NOT NULL DEFAULT '',
  `field_size` int(3) NOT NULL DEFAULT '0',
  `field_size_min` int(3) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` text,
  `default` varchar(255) NOT NULL DEFAULT '',
  `widget` varchar(255) NOT NULL DEFAULT '',
  `widgetparams` text,
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `tbl_profiles_fields`
--

INSERT INTO `tbl_profiles_fields` (`id`, `varname`, `title`, `field_type`, `field_size`, `field_size_min`, `required`, `match`, `range`, `error_message`, `other_validator`, `default`, `widget`, `widgetparams`, `position`, `visible`) VALUES
(1, 'first_name', 'First Name', 'VARCHAR', 255, 3, 2, '', '', 'Incorrect First Name (length between 3 and 50 characters).', '', '', '', '', 1, 3),
(2, 'last_name', 'Last Name', 'VARCHAR', 255, 3, 2, '', '', 'Incorrect Last Name (length between 3 and 50 characters).', '', '', '', '', 2, 3);

-- --------------------------------------------------------

--
-- 表的结构 `tbl_users`
--

DROP TABLE IF EXISTS `tbl_users`;
CREATE TABLE IF NOT EXISTS `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(128) NOT NULL DEFAULT '',
  `email` varchar(128) NOT NULL DEFAULT '',
  `activkey` varchar(128) NOT NULL DEFAULT '',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastvisit_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_username` (`username`),
  UNIQUE KEY `user_email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `username`, `password`, `email`, `activkey`, `superuser`, `status`, `create_at`, `lastvisit_at`) VALUES
(1, 'admin', '406319e986398247e47bdcb4d5c59831', 'webmaster@example.com', '669360d2530cbea3b4f4b9119e895bd2', 1, 1, '2012-11-16 09:45:59', '2012-12-04 18:35:20'),
(2, 'xami', '406319e986398247e47bdcb4d5c59831', 'xami520@qq.com', '6a6c20e323d61f476d6461f0d9a14cbd', 0, 0, '2012-11-19 02:34:56', '0000-00-00 00:00:00'),
(3, 'xami520', '406319e986398247e47bdcb4d5c59831', '77765997@qq.com', '56b747a929c639c717fb0f1b81aa6fa5', 0, 0, '2012-11-27 05:33:51', '0000-00-00 00:00:00');

--
-- 限制导出的表
--

--
-- 限制表 `blog_authassignment`
--
ALTER TABLE `blog_authassignment`
  ADD CONSTRAINT `blog_authassignment_ibfk_1` FOREIGN KEY (`itemname`) REFERENCES `blog_authitem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `tbl_profiles`
--
ALTER TABLE `tbl_profiles`
  ADD CONSTRAINT `user_profile_id` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
