-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2013 年 01 月 14 日 11:49
-- 服务器版本: 5.2.12-MariaDB-mariadb115
-- PHP 版本: 5.3.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `cefls`
--

-- --------------------------------------------------------

--
-- 表的结构 `blog_ads`
--

DROP TABLE IF EXISTS `blog_ads`;
CREATE TABLE IF NOT EXISTS `blog_ads` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text,
  `img` varchar(255) NOT NULL,
  `url` char(255) NOT NULL,
  `cid` tinyint(2) NOT NULL DEFAULT '0',
  `type` tinyint(2) NOT NULL DEFAULT '0',
  `order` int(4) NOT NULL DEFAULT '0',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=117 ;

--
-- 转存表中的数据 `blog_ads`
--

INSERT INTO `blog_ads` (`aid`, `title`, `content`, `img`, `url`, `cid`, `type`, `order`, `enabled`) VALUES
(1, '成都外国语学校', NULL, '/images/temp/20502107669c31504905f839aa6f55da.jpg', 'http://www.jsj.com', 0, -1, 0, 0),
(2, 'dafasdfasdfasdf', NULL, '/images/temp/a0d51471bcb57d44fbd17eda772cc06d.jpg', '/images/temp/a0d51471bcb57d44fbd17eda772cc06d.jpg', -1, -3, 0, 0),
(3, 'asdfasdfasdf', NULL, '/images/temp/0e8f18bffa4f8256d81b987cc80787de.jpg', '/images/temp/0e8f18bffa4f8256d81b987cc80787de.jpg', -1, -3, 0, 0),
(4, 'asdfasdf', NULL, '/images/temp/b0a583a6424a444eb681c1e0688544e6.jpg', 'http://www.baidu.com', 0, 5, 0, 1),
(5, 'asdfasdf', NULL, '/images/temp/ade15514b2c1f116e9297bb3c9856e5d.jpg', 'http://www.baidu.com', 0, 62, 0, 1),
(6, '成都外国语学校', NULL, '', 'http://www.cfls.net.cn', 0, -6, 1, 1),
(7, '哈尔滨工业大学(www.haerbinggydx.com)', '       天体学领域有很多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。州大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。', '/images/temp/13fa4a2d242d081ef413fb9a15e0482a.jpg', 'http://www.baidu.com', 6, 0, 0, 0),
(8, '哈尔滨工业大学(www.haerbinggydx.com)', ' 天体学领域有很多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。州大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。\r\n\r\n', '/images/temp/3384ff9ae960ae7c24b26dd4691636f6.jpg', 'http://www.baidu.com', 6, 0, 0, 0),
(9, '哈尔滨工业大学(www.haerbinggydx.com)', ' 天体学领域有很多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。州大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。\r\n\r\n', '/images/temp/3c65729aaef06c286018c11ef264c766.jpg', 'http://www.baidu.com', 6, 0, 0, 0),
(10, '哈尔滨工业大学(www.haerbinggydx.com)', ' 天体学领域有很多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。州大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。\r\n\r\n', '/images/temp/efebb32b6d094a6c46e6c5831ad321e6.jpg', 'http://www.baidu.com', 6, 0, 0, 0),
(11, '哈尔滨工业大学(www.haerbinggydx.com)', ' 天体学领域有很多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。州大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。多悬而未决的问题。比如说，我们对于宇宙的具体组成还不清楚，只是粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。大学高能天体计算中心主任，天体学领域有很多悬而未决的问题。比如说，我们对粗浅地了解有些暗物质、暗能量在操纵着宇宙。如果了解了暗能量的本质，就可以解读未来。因此，我们希望探寻暗物质的真正本质。这一研究工作非常有挑战性，将需要海量的计算和存储。云计算的出现，使处理海量数据的方式更为灵活。加州大学高能天体计算中心主任。\r\n\r\n', '/images/temp/46bb74c311429d23a4545a295e3cea7e.jpg', 'http://www.baidu.com', 6, 0, 0, 0),
(12, '温瑞征', NULL, '/images/temp/503f4610691bfb9acfa3ecdd880048db.jpg', 'http://www.baidu.com', 0, -7, 0, 1),
(13, '李佳', NULL, '/images/xzfc/1a89aded92a0ba85acf94e494a5c6ac4.jpg', '2012四川省高考文科状元', 50, -10, 0, 0),
(14, '王军', NULL, '/images/xzfc/f69907a068ca3434973b4372dc8558fc.jpg', '2012四川省高考文科状元', 50, -10, 0, 0),
(15, '王军2', NULL, '/images/xzfc/0b5641a75f8072bac58928a4710f393a.jpg', '2012四川省高考文科状元2', 50, -10, 0, 0),
(16, 'xxxx', NULL, '/images/temp/e25c57e45913dc310c9b80e7efc56248.swf', 'http://www.baidu.com', 0, 1, 0, 1),
(17, 'xuexiao ', NULL, '/images/temp/22b3ea57a031d7867f8653feb75b40a9.jpg', 'http://www.cefls.com', 0, -1, 0, 0),
(18, 'xuesheng ', NULL, '/images/temp/a809e9009badcd57f5bc4dd1bfc6c02b.jpg', 'http://www.cefls.cn', 0, -1, 0, 0),
(19, 'jiaoshi', NULL, '/images/temp/43a12df8a35a7d71ba3ae954ea84a4ec.jpg', 'http://www.cefls.cn', 0, -1, 0, 0),
(20, 'teachers', NULL, '/images/temp/de210b069199ee5184dcaf355f3a3aab.swf', 'http://www.cefls.cn', 0, 2, 0, 1),
(21, 'deyu', NULL, '/images/temp/d69dd9d9dbbbb443e91da043be2d25fe.jpg', 'http://www.cefls.cn', 0, 3, 0, 1),
(22, 'teaching', NULL, '/images/temp/b02092e49bf71a01b3f331495f4f32d0.swf', 'http://www.cefls.cn', 0, 4, 0, 1),
(23, 'jiaoliu', NULL, '/images/temp/27f3094df48a32ea39c9d0c41080a4ef.swf', 'http://www.cefls.cn', 0, 6, 0, 1),
(24, 'xuezi', NULL, '/images/temp/4f99a041c58b3d672a1230ec537a66de.swf', 'http://www.cefls.cn', 0, 7, 0, 1),
(25, 'yiti', NULL, '/images/temp/5cc7da2bc448e9acf17804df604ad036.swf', 'http://www.cefls.cn', 0, 8, 0, 1),
(26, 'ganwu', NULL, '/images/temp/511ff3f803b592d554de65888154f4ac.jpg', '', 0, 9, 0, 1),
(27, 'fayuzhong', NULL, '/images/temp/716dac014eba1078be570719c9ab8ad5.jpg', '', 0, 63, 0, 1),
(28, 'deyuzhong', NULL, '/images/temp/2d60ea8a28ff39771232244f0b3815d9.jpg', '', 0, 64, 0, 1),
(29, 'chaxun', NULL, '/images/temp/daa68d2c2ec7261ff7993e72f74f70ca.jpg', 'http://www.cefls.cn', 0, -2, 1, 1),
(30, 'guanggao', NULL, '/images/temp/4765ca40efad472317e0ee4e827e005c.jpg', 'http://www.cefls.cn', 0, -2, 2, 1),
(31, 'zhaoin', NULL, '/images/temp/326af401d01b1db3b6d583af8e637e06.jpg', 'http://www.cefls.cn', 0, -2, 3, 1),
(32, 'zhuti', NULL, '/images/temp/fba93a650591b94675133ab1c936e477.swf', '', 0, -1, 0, 0),
(33, 'teacers', NULL, '/images/temp/052a819680bf00f8893603139301fffa.jpg', '', 0, -1, 0, 1),
(34, 'students', NULL, '/images/temp/3cfe76bdc4388fce3e89a100243ed5ec.jpg', '', 0, -1, 0, 1),
(35, 'school', NULL, '/images/temp/69f2bbf064e974ac6696d3b56bb2502c.jpg', '', 0, -1, 0, 1),
(36, '二十世纪九十年代获取四川省五四荣誉称号', NULL, '/images/temp/29f35dd7d5480a63528140e9cc19b241.jpg', '/images/temp/29f35dd7d5480a63528140e9cc19b241.jpg', -1, -3, 0, 0),
(37, '成都市实验外国语学校网站文案包\\魅力实外\\1、德育为先 做人第一\\6、德育硕果\\6.JPG', NULL, '/images/temp/0ed01d52f3c75fa95ae5629b64b87959.JPG', '/images/temp/0ed01d52f3c75fa95ae5629b64b87959.JPG', -1, -3, 0, 0),
(38, '成都市实验外国语学校网站文案包\\魅力实外\\1、德育为先 做人第一\\6、德育硕果\\6.JPG', NULL, '/images/temp/7b6155c2aff4da2025f9ee8789527c12.JPG', '/images/temp/7b6155c2aff4da2025f9ee8789527c12.JPG', -1, -3, 0, 0),
(39, '成都市实验外国语学校网站文案包\\魅力实外\\1、德育为先 做人第一\\6、德育硕果\\6.JPG', NULL, '/images/temp/804fd6a1337a38912595ace1fa71c694.JPG', '/images/temp/804fd6a1337a38912595ace1fa71c694.JPG', -1, -3, 0, 0),
(40, '对那些在他们苦难时未离弃他们的忠实朋友，我们应该与他们一样心怀感激；我们从心底里也和他们一样怼怨那些背信弃义乃至伤害、离弃或欺骗他们的叛徒。', NULL, '/images/temp/bcf244d266d1dff2d76886a8ae21b4a7.JPG', '/images/temp/bcf244d266d1dff2d76886a8ae21b4a7.JPG', -1, -3, 0, 0),
(41, '成都市实验外国语学校网站文案包\\魅力实外\\2、 教学为重  质量至上\\5、硕果累累\\1、09年成都市教育局高中教育工作突出贡献奖.jpg', NULL, '/images/temp/bba7bf64beedcfe16aa29ce42fcbe409.jpg', '/images/temp/bba7bf64beedcfe16aa29ce42fcbe409.jpg', -1, -3, 0, 0),
(42, ':\\成都市实验外国语学校网站文案包\\魅力实外\\2、 教学为重  质量至上\\5、硕果累累\\2、2010年成都市教育局高中教育工作突出贡献奖.jpg', NULL, '/images/temp/a644b7250654623e5056f9de0fdb9ce3.jpg', '/images/temp/a644b7250654623e5056f9de0fdb9ce3.jpg', -1, -3, 0, 0),
(43, '成都市实验外国语学校网站文案包\\魅力实外\\2、 教学为重  质量至上\\5、硕果累累\\09年教育局教育工作突出贡献奖励.jpg', NULL, '/images/temp/ffb7c6b1d52c2b9679d45d64829c77bc.jpg', '/images/temp/ffb7c6b1d52c2b9679d45d64829c77bc.jpg', -1, -3, 0, 0),
(44, ':\\成都市实验外国语学校网站文案包\\魅力实外\\2、 教学为重  质量至上\\5、硕果累累\\art20091211103054993719.jpg', NULL, '/images/temp/46da7279cb597e8ea3a944e14cd0829f.jpg', '/images/temp/46da7279cb597e8ea3a944e14cd0829f.jpg', -1, -3, 0, 0),
(45, 'F:\\成都市实验外国语学校网站文案包\\魅力实外\\2、 教学为重  质量至上\\5、硕果累累\\DSCF0007.JPG', NULL, '/images/temp/dcdaf78d4aa4ccc63f1870d5d1a94e60.JPG', '/images/temp/dcdaf78d4aa4ccc63f1870d5d1a94e60.JPG', -1, -3, 0, 0),
(46, '成都市实验外国语学校网站文案包\\魅力实外\\2、 教学为重  质量至上\\5、硕果累累\\IMG_7572.jpg', NULL, '/images/temp/fda5b3128ac3f722888bbb88ac8d5202.jpg', '/images/temp/fda5b3128ac3f722888bbb88ac8d5202.jpg', -1, -3, 0, 0),
(47, '成都市实验外国语学校网站文案包\\魅力实外\\2、 教学为重  质量至上\\5、硕果累累\\IMG_7572.jpg', NULL, '/images/temp/3f6c2334c4feb6d9519e660466dfd293.jpg', '/images/temp/3f6c2334c4feb6d9519e660466dfd293.jpg', -1, -3, 0, 0),
(48, '成都市实验外国语学校网站文案包\\魅力实外\\2、 教学为重  质量至上\\5、硕果累累\\IMG_7572.jpg', NULL, '/images/temp/c8150afdbec51f9e57ef134a57166d28.jpg', '/images/temp/c8150afdbec51f9e57ef134a57166d28.jpg', -1, -3, 0, 0),
(49, '成都市实验外国语学校网站文案包\\魅力实外\\2、 教学为重  质量至上\\5、硕果累累\\IMG_7572.jpg', NULL, '/images/temp/84ed577f95844a5fdbd41fb094533082.jpg', '/images/temp/84ed577f95844a5fdbd41fb094533082.jpg', -1, -3, 0, 0),
(50, '成都市实验外国语学校网站文案包\\魅力实外\\2、 教学为重  质量至上\\5、硕果累累\\IMG_7572.jpg', NULL, '/images/temp/775959a2a02593de776f3606e7ed102f.JPG', '/images/temp/775959a2a02593de776f3606e7ed102f.JPG', -1, -3, 0, 0),
(51, '成都市实验外国语学校网站文案包\\魅力实外\\2、 教学为重  质量至上\\5、硕果累累\\IMG_7572.jpg', NULL, '/images/temp/592f487b8337af8b2c847631a12eda42.JPG', '/images/temp/592f487b8337af8b2c847631a12eda42.JPG', -1, -3, 0, 0),
(52, '成都市实验外国语学校网站文案包\\魅力实外\\2、 教学为重  质量至上\\5、硕果累累\\IMG_7572.jpg', NULL, '/images/temp/08f0454218ec27ab2f751cec8a110183.jpg', '/images/temp/08f0454218ec27ab2f751cec8a110183.jpg', -1, -3, 0, 0),
(53, '成都市实验外国语学校网站文案包\\魅力实外\\2、 教学为重  质量至上\\5、硕果累累\\IMG_7572.jpg', NULL, '/images/temp/88ca40bb1063e9f6112f3f948cd7ff5e.jpg', '/images/temp/88ca40bb1063e9f6112f3f948cd7ff5e.jpg', -1, -3, 0, 0),
(54, '成都市实验外国语学校网站文案包\\魅力实外\\2、 教学为重  质量至上\\5、硕果累累\\IMG_7572.jpg', NULL, '/images/temp/82c83c6d6ffbcaccd67a6748a529ccd7.JPG', '/images/temp/82c83c6d6ffbcaccd67a6748a529ccd7.JPG', -1, -3, 0, 0),
(55, 'jiaoshi', NULL, '/images/temp/d873548409ad874e0a19a600d6af540d.jpg', '', 0, -1, 0, 1),
(56, '成都市实验外国语学校（西区）', NULL, '', 'http://www.cdswxq.com', 0, -6, 2, 1),
(57, '四川外语学院成都学院', NULL, '', 'http://www.cisisu.edu.cn', 0, -6, 3, 1),
(58, '四川省计算机学会', NULL, '', 'http://www.spcf.cn', 0, -6, 4, 1),
(59, '成都市第七中学', NULL, '', 'http://www.cdqz.net', 0, -6, 5, 1),
(60, '成都树德中学', NULL, '', 'http://www.sdzx.net', 0, -6, 7, 1),
(61, '成都石室中学', NULL, '', 'ttp://www.cdshishi.net', 0, -6, 8, 1),
(62, '绵阳东辰国际学校', NULL, '', 'http://www.mydcis.net', 0, -6, 8, 1),
(63, '绵阳南山中学', NULL, '', 'http://www.scmyns.com', 0, -6, 9, 1),
(64, '成都市教育局', NULL, '', 'http://www.cdedu.gov.cn', 0, -6, 9, 1),
(65, '四川省教育厅', NULL, '', 'http://www.scedu.net', 0, -6, 10, 1),
(66, '中国国家教育部', NULL, '', 'http://www.moe.gov.cn', 0, -6, 12, 1),
(67, '成都市实验外国语学校第20届教学年会成功召开。', NULL, '/images/temp/e63c8aab2f7c58afcb3cce89fb42e725.jpg', '', 0, -8, 0, 1),
(68, '江伟丽', '', '/images/xzfc/588063420e666e02cc5f760f49d2cb84.JPG', '2004年四川省高考文科状元', 50, -10, 1, 0),
(69, '江伟丽', '', '/images/xzfc/940eeba2c899cef62087a917488d9b68.JPG', '2004年四川省高考文科状元', 50, -10, 1, 0),
(70, '江伟丽', '', '/images/xzfc/e9572a0ec549170f2e22c257724d2a57.png', '2004年四川省高考文科状元', 50, -10, 1, 0),
(71, 'zhutu', NULL, '/images/temp/ae51d3c98ca3775a7849b802c27ff7a4.swf', '', 0, -1, 0, 1),
(72, 'dsfas', NULL, '/images/temp/daa355dc609b6578d348146717c738f2.jpg', '/images/temp/daa355dc609b6578d348146717c738f2.jpg', -1, -3, 0, 0),
(73, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！\r\n', NULL, '/images/temp/f5bca6cb3cce8560f41d510aaf6593bf.jpg', '/images/temp/f5bca6cb3cce8560f41d510aaf6593bf.jpg', -1, -3, 0, 1),
(74, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/71972acc920eb2722e3ddaeb79c5d6b0.jpg', '/images/temp/71972acc920eb2722e3ddaeb79c5d6b0.jpg', -1, -3, 0, 1),
(75, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/74ea5bee4c59a0d27464049949258814.jpg', '/images/temp/74ea5bee4c59a0d27464049949258814.jpg', -1, -3, 0, 1),
(76, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/05201aca2bd6e7b681ab08bd18e8a75c.jpg', '/images/temp/05201aca2bd6e7b681ab08bd18e8a75c.jpg', -1, -3, 0, 1),
(77, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/5270d9815854a3e8843337e1eb83c217.jpg', '/images/temp/5270d9815854a3e8843337e1eb83c217.jpg', -1, -3, 0, 1),
(78, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/60447d9ba38dadad388e1f5d4b64f902.jpg', '/images/temp/60447d9ba38dadad388e1f5d4b64f902.jpg', -1, -3, 0, 1),
(79, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/98f64f09ba8e54faed41edb235625412.JPG', '/images/temp/98f64f09ba8e54faed41edb235625412.JPG', -1, -3, 0, 1),
(80, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/8488f80471f70f7038c3683b8fc62686.jpg', '/images/temp/8488f80471f70f7038c3683b8fc62686.jpg', -1, -3, 0, 1),
(81, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/b133972c4fe02a7018433f59405f5f84.jpg', '/images/temp/b133972c4fe02a7018433f59405f5f84.jpg', -1, -3, 0, 1),
(82, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/984e827f6242b75237003d24f3529c49.jpg', '/images/temp/984e827f6242b75237003d24f3529c49.jpg', -1, -3, 0, 1),
(83, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/88fe4f0296e7bc1b6cac0f3031ed1cf7.jpg', '/images/temp/88fe4f0296e7bc1b6cac0f3031ed1cf7.jpg', -1, -3, 0, 1),
(84, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/c915ed667768452f7eb24e6ac8381cb5.jpg', '/images/temp/c915ed667768452f7eb24e6ac8381cb5.jpg', -1, -3, 0, 1),
(85, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/f6afe25729e40256b7ae156f2ac5a59f.jpg', '/images/temp/f6afe25729e40256b7ae156f2ac5a59f.jpg', -1, -3, 0, 1),
(86, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/94f2fe9fbc65779ca2d9a698033f3aef.jpg', '/images/temp/94f2fe9fbc65779ca2d9a698033f3aef.jpg', -1, -3, 0, 1),
(87, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/38d026e8e91328491194e7ae30230306.jpg', '/images/temp/38d026e8e91328491194e7ae30230306.jpg', -1, -3, 0, 1),
(88, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/307436e1d64cea388e7bd2681fa30715.JPG', '/images/temp/307436e1d64cea388e7bd2681fa30715.JPG', -1, -3, 0, 1),
(89, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/9dda4f337ce17308f0f590c26509af94.jpg', '/images/temp/9dda4f337ce17308f0f590c26509af94.jpg', -1, -3, 0, 1),
(90, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/d60f54d837e52c36cfecf00f3d26db7e.jpg', '/images/temp/d60f54d837e52c36cfecf00f3d26db7e.jpg', -1, -3, 0, 1),
(91, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/4338c54c358a1663725565ae94fa79ea.jpg', '/images/temp/4338c54c358a1663725565ae94fa79ea.jpg', -1, -3, 0, 1),
(92, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/194bbeff3f47f48496292afe4df75566.jpg', '/images/temp/194bbeff3f47f48496292afe4df75566.jpg', -1, -3, 0, 1),
(93, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/6fe9dbb622fd568f8034e909cdf00ba7.jpg', '/images/temp/6fe9dbb622fd568f8034e909cdf00ba7.jpg', -1, -3, 0, 1),
(94, '成都实外，名副其实，实至名归，万流景仰，人才辈出，桃李满天下！', NULL, '/images/temp/8c95a210ce665ae4fc5660be89f31aa3.jpg', '/images/temp/8c95a210ce665ae4fc5660be89f31aa3.jpg', -1, -3, 0, 1),
(95, '北京大学<http://www.pku.edu.cn>', '        北京大学创办于1898年，初名京师大学堂，是中国第一所国立大学，也是中国近代正式设立的第一所大学，其成立标志着中国近代高等教育的开端。\r\n    北京大学是中国近代第一个以“大学”身份（名称）建立的学校，也是近代最早的综合性大学，并催生了中国最早的现代学制。北大是中国近代惟一以最高学府身份创立的大学，最初也是当时的国家最高教育行政机关，行使国家教育部职能，统管全国教育。北大传承着中国数千年来国家最高学府——太学（国子学、国子监）的学统，建立之初身兼传统太学制度与现代大学建置的双重身份，既继承了中国古代最高学府正统，又开创了中国近代高等教育先河，可谓“上承太学正统，下立大学祖庭”。自建校以来，一直享有崇高的名声和地位。1912年，京师大学堂更名国立北京大学。\r\n        北京大学是中国最高学府，同时也是中国综合实力第一的大学，理科、文科、社会科学、新型工科和医科都是它的强项。全校共拥有国家重点学科81个，在全国高校中遥遥领先（比第二名多出32个）。按照国家重点学科，北大的理科、文科、医科实力均为全国第一。作为中国高等教育的奠基者，北大诞生了中国高校中最早的数学、物理、化学、地质、计算机、微电子、核物理、心理、农学、医学、中文、历史、哲学、考古、外语、政治、经济、商学、新闻等学科，也是第一所招收研究生的中国大学。\r\n     北京大学作为中国教育部直属高校，及国家首批“211工程”和“985工程”系列的重点大学，是国家“111计划”和“珠峰计划”重点建设的名牌大学，亦是东亚研究型大学协会、国际研究型大学联盟、环太平洋大学联盟、东亚四大学论坛、国际公立大学论坛、九校联盟（C9）和基础学科拔尖学生培养试验计划的成员。\r\n     北京大学作为新文化运动的中心和五四运动的发祥地、中国最早的马克思主义和民主科学思想的源头之一，以及中国共产党最早的活动根据地之一，北大为民族的振兴和解放、国家的建设和发展、社会的文明和进步做出了不可替代的贡献，在中国走向现代化的进程中起到了重要的先锋作用。爱国、进步、民主、科学的传统精神和勤奋、严谨、求实、创新的学风，在这里生生不息、代代相传。现任校长周其凤院士、党委书记朱善璐教授。\r\n', '/images/temp/46fc3d20b40d619bbd58e4d89651cc53.jpg', 'http://www.pku.edu.cn/', 6, 0, 0, 1),
(96, '余静阑', '', '/images/xzfc/193a431a192bec5a3209a68e5da09cb3.jpg', '1999年四川省高考文科状元', 50, -10, 0, 0),
(97, '余静阑', '', '/images/xzfc/d11de929993c79b75bbbd2db518e742f.jpg', '1999年四川省高考文科状元', 50, -10, 0, 0),
(98, '刘洋洋', '', '/images/xzfc/625f3ce8340742e387542cad0e9f6658.jpg', '2000年四川省高考文科状元', 50, -10, 0, 0),
(99, '刘梦羽', '', '/images/xzfc/2f33ef2db463874c03159c787e1424b9.jpg', '2003年四川省高考文科状元', 50, -10, 0, 0),
(100, '江伟丽', '', '/images/xzfc/0710ea364a0767a27bc32d01b3477088.jpg', '2004年四川省高考文科状元', 50, -10, 0, 0),
(101, '代媛媛', '', '/images/xzfc/aed4db91911d0d3cc51287ccddf43377.jpg', '2006年四川省高考文科状元', 50, -10, 0, 0),
(102, '叶思雨', '', '/images/xzfc/8b87dffa5c7d60b1bf963005b928620a.jpg', '2009年四川省高考文科状元', 50, -10, 0, 0),
(103, '向昊天', '', '/images/xzfc/7a7984668925c807f6e8f68358842b1a.jpg', '2010年四川省高考文科状元', 50, -10, 0, 0),
(104, '向昊天', '', '/images/xzfc/065f2c3ce2e0cbf5d598d1a2e323a8d2.jpg', '2010年四川省高考文科状元', 50, -10, 0, 0),
(105, '测试', '', '/images/xzfc/a77c30daa15f6186beab272ab18f41b8.jpg', '测试', 50, -10, 0, 0),
(106, '清华大学', '         清华大学（Tsinghua University）是中国著名高等学府，坐落于北京西北郊风景秀丽的清华园,是中国高层次人才培养和科学技术研究的重要基地。\r\n     清华大学的前身是清华学堂，成立于1911年，当初是清政府建立的留美预备学校。1912 年更名为清华学校，为尝试人才的本地培养，1925 年设立大学部，同年开办国学研究院，1928年更名为“国立清华大学”。1937年抗日战争爆发后，南迁长沙，与北京大学、南开大学联合办学，组建国立长沙临时大学，1938年迁至昆明，改名为国立西南联合大学。1946年，清华大学迁回清华园原址复校。\r\n     1952年，全国高校院系调整后，清华大学成为一所多科性工业大学，重点为国家培养工程技术人才，被誉为“红色工程师的摇篮”。1978年以来，清华大学进入了一个蓬勃发展的新时期，逐步恢复了理科、经济、管理和文科类学科，并成立了研究生院和继续教育学院。1999 年，原中央工艺美术学院并入，成立清华大学美术学院。在国家和教育部的大力支持下，经过“211工程”建设和“985工程”的实施，清华大学在学科建设、人才培养、师资队伍、科学研究、国际合作、社会服务以及整体办学条件等方面均跃上了一个新的台阶。目前，清华大学设有16个学院，56个系，已成为一所具有理学、工学、文学、艺术学、历史学、哲学、经济学、管理学、法学、教育学和医学等学科的综合性、研究型、开放式大学。\r\n    清芬挺秀，华夏增辉。今天的清华大学面临前所未有的历史机遇，清华人将秉持“自强不息、厚德载物”的校训，发扬“爱国奉献，追求卓越”的优良传统、“行胜于言”的校风以及“严谨、勤奋、求实、创新”的学风，为使清华大学跻身世界一流大学行列，为中华民族的伟大复兴而努力奋斗。\r\n', '/images/temp/a04da19ab9f20d221bf9a385100ec6a1.jpg', 'http://www.tsinghua.edu.cn', 6, 0, 0, 1),
(107, '中国科学技术大学', '    中国科学技术大学是中国科学院所属的一所以前沿科学和高新技术为主、兼有特色管理和人文学科的综合性全国重点大学。\r\n   1958年9月创建于北京，首任校长由郭沫若兼任。它的创办被称为“我国教育史和科学史上的一项重大事件”。建校后，中国科学院实施“全院办校，所系结合”的办学方针，学校紧紧围绕国家急需的新兴科技领域设置系科专业，创造性地把理科与工科即前沿科学与高新技术相结合，注重基础课教学，高起点，宽口径培养新兴、边缘、交叉学科的尖端科技人才，汇集了严济慈、华罗庚、钱学森、赵忠尧、郭永怀、赵九章、贝时璋等一批国内最有声望的科学家， 得到迅速发展，建校第二年即被列为全国重点大学。\r\n    1970年初，学校迁至安徽省合肥市，开始了第二次创业。1978年以后，学校锐意改革，大胆创新，在全国率先提出并实施了创办少年班、首建研究生院、建设国家大科学工程、面向世界开放办学等一系列具有创新精神和前瞻意识的教育改革措施，得到迅速恢复和发展。“七五”、“八五”期间一直得到国家的重点建设，很快发展成为国家高质量人才培养和高水平科学研究的重要基地。 \r\n    20世纪90年代以来，学校主动适应国内外科技、教育和社会经济发展的要求与挑战，认真贯彻《中国教育改革和发展纲要》，大力推行教学科研改革和结构性调整，进行第三次创业。学校是国家首批实施“985工程”和“211工程”的大学之一，也是唯一参与国家知识创新工程的大学。\r\n    长期以来，学校大力弘扬“红专并进，理实交融”的校风，坚持“我创新，故我在”和精品办学、英才教育的理念，形成了不断开拓创新的优良传统，以及教学与科研相结合、理论与实践相结合的鲜明特色，培养出一批德才兼备的高层次优秀人才。学校面向世界科学前沿领域和国家重大需求，凝练科学目标，开展科学研究，努力提高学术研究水平和科研创新能力与科研竞争力，取得了一批具有世界领先水平的原创性科技成果。\r\n    学校有14个学院、27个系，以及研究生院、软件学院等，在上海、苏州分别设有研究院。有数学、物理学、力学、天文学、生物科学、化学共6个国家理科基础科学研究和教学人才培养基地和1个国家生命科学与技术人才培养基地，8个一级学科国家重点学科，4个二级学科国家重点学科，2个国家重点培育学科，1个安徽省A类重点学科，19个安徽省B类重点学科。建有国家同步辐射实验室、合肥微尺度物质科学国家实验室（筹）、火灾科学国家重点实验室、国家高性能计算中心（合肥）、蒙城地球物理国家野外科学观测研究站等38个国家和院省部级重点科研机构。\r\n    学校拥有一支高素质的师资队伍。现有专任教师1553人，其中教授522人（含相当专业技术职务人员），副教授671人（含相当专业技术职务人员），中国科学院和中国工程院院士37人，第三世界科学院院士10人，“千人计划”36人，“青年千人计划”69人，教育部“长江学者奖励计划”特聘教授24人、讲座教授9人，国家杰出青年基金获得者85人，国家级教学名师7人，中国科学院“百人计划”139人。同时，一批国内外著名学者受聘担任名誉（客座）教授、“大师讲席”教授。\r\n    在校学生15500多人，其中博士生1900多人，硕士生6200多人，本科生7400多人。本科生生源和培养质量一直在全国高校中名列前茅。\r\n     校园总面积约165万平方米，建筑面积104万平方米，拥有资产总值12.7亿元的先进教学科研仪器设备，图书馆藏书197.1万册，已建成国内一流水平的校园计算机网络，并初步建成若干科研、教学公共实验中心。\r\n    目前，全校上下正深化改革，锐意创新，力争在2018年建校60周年前后，把学校建设成为质量优异、特色鲜明、规模适度、结构合理的一流研究型大学，成为与中国科学院和其他专业研究院所及高科技企业相结合，面向全国培养具有创新能力和现代知识结构的一流人才，具有较强知识创新和技术创新能力的教育与科研基地，为实现“创寰宇学府，育天下英才”的宏伟目标而努力奋斗。\r\n', '/images/temp/1a7c21c0c4c32d47a5a9db3ba3483969.jpg', 'http://www.ustc.edu.cn', 6, 0, 0, 1),
(108, 'Harvard University', '       Harvard University is devoted to excellence in teaching, learning, and research, and to developing leaders in many disciplines who make a difference globally. Harvard faculty are engaged with teaching and research to push the boundaries of human knowledge. For students who are excited to investigate the biggest issues of the 21st century, Harvard offers an unparalleled student experience and a generous financial aid program, with over $160 million awarded to more than 60% of our undergraduate students. The University has twelve degree-granting Schools in addition to the Radcliffe Institute for Advanced Study, offering a truly global education.\r\n            Established in 1636, Harvard is the oldest institution of higher education in the United States. The University, which is based in Cambridge and Boston, Massachusetts, has an enrollment of over 20,000 degree candidates, including undergraduate, graduate, and professional students. Harvard has more than 360,000 alumni around the world.\r\n', '/images/temp/afb3fd4d1ee8017f23bf89c5ce3150eb.jpg', 'http://www.harvard.edu', 6, 0, 0, 1),
(109, ' University of Cambridge', '     We are one of the world''s oldest universities and leading academic centres, and a self-governed community of scholars. Cambridge comprises 31 Colleges and over 150 departments, faculties, schools and other institutions.\r\n         A college is where students live, eat and socialise. It is also the place where students receive small group teaching sessions, known as supervisions.\r\n          Each college is an independent institution with its own property and income. The colleges appoint their own staff and are responsible for selecting students, in accordance with University regulations. The teaching of students is shared between the Colleges and University departments. Degrees are awarded by the University.\r\nThe University of Cambridge is rich in history - its famous Colleges and University buildings attract visitors from all over the world. But the University''s museums and collections also hold many treasures which give an exciting insight into some of the scholarly activities, both past and present, of the University''s academics and students.\r\n          The University of Cambridge is one of the world''s oldest universities and leading academic centres, and a self-governed community of scholars. Its reputation for outstanding academic achievement is known world-wide and reflects the intellectual achievement of its students, as well as the world-class original research carried out by the staff of the University and the Colleges.\r\n          Many of the University''s customs and unusual terminology can be traced to roots in the early years of the University''s long history, and this booklet looks to the past to find the origins of much that is distinctive in the University of today.\r\n', '/images/temp/813130ea48606c5f6808a3cf78b54dd1.jpg', 'http://www.cam.ac.uk', 6, 0, 0, 1),
(110, '余静阑', '', '/images/xzfc/6ab570a7bea69f729e2ff9a31f7d0491.jpg', '1999年，四川省高考文科状元', 50, -10, 0, 1),
(111, '刘洋洋', '', '/images/xzfc/155dba54971ef4eebfd039b6f2c4922a.jpg', '2000年，四川省高考文科状元', 50, -10, 0, 1),
(112, '刘梦羽', '', '/images/xzfc/80d596579088323ed1d8b7f6cc70a5fa.jpg', '2003年，四川省高考文科状元', 50, -10, 0, 1),
(113, '江伟丽', '', '/images/xzfc/82862772f8952f12dbb5eb9e26f9a37c.jpg', '2004年，四川省高考文科状元', 50, -10, 0, 1),
(114, '代媛媛', '', '/images/xzfc/75e7b541791bf8641a56e8b994f24377.jpg', '2006年，四川省高考文科状元', 50, -10, 0, 1),
(115, '叶思雨', '', '/images/xzfc/4d18a6ad339fac8c4f343e3f0324e0f9.jpg', '2009年，四川省高考文科状元', 50, -10, 0, 1),
(116, '向昊天', '', '/images/xzfc/320b05b530195f3e52562dee19877246.jpg', '2010年，四川省高考文科状元', 50, -10, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `blog_article`
--

DROP TABLE IF EXISTS `blog_article`;
CREATE TABLE IF NOT EXISTS `blog_article` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `src` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `from` varchar(255) DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `cid` int(2) NOT NULL,
  `audit` tinyint(2) NOT NULL,
  `grade` tinyint(1) NOT NULL,
  `createtime` datetime NOT NULL,
  `updatetime` datetime NOT NULL,
  `title` text NOT NULL,
  `excerpt` text NOT NULL,
  `content` longtext NOT NULL,
  `author` varchar(64) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `sort` int(8) NOT NULL,
  `type` smallint(2) NOT NULL,
  `clicknumber` int(8) DEFAULT '0',
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=52 ;

--
-- 转存表中的数据 `blog_article`
--

INSERT INTO `blog_article` (`aid`, `src`, `file`, `from`, `uid`, `cid`, `audit`, `grade`, `createtime`, `updatetime`, `title`, `excerpt`, `content`, `author`, `enabled`, `sort`, `type`, `clicknumber`) VALUES
(1, NULL, NULL, NULL, 1, 16, 1, 0, '2013-01-11 00:00:00', '2012-12-12 04:16:59', 'xxx', 'bbb', 'asdfasdf', NULL, 0, 0, 0, 0),
(2, NULL, NULL, 'asdfas', 1, -1, 1, 0, '2012-12-12 05:13:45', '2012-12-12 05:25:38', 'xxx', '', '<p>ddasfaasdfasdf</p>', 'asdfa', 1, 0, 0, 0),
(3, NULL, NULL, '管理员', 1, -1, 1, 0, '2012-12-13 02:46:34', '2012-12-13 05:45:39', '大事纪要', '', '<p>撒旦法士大夫</p>', '管理员', 0, 0, 0, 28),
(4, NULL, NULL, '成都市实验外国语学校', 1, -1, 1, 0, '2012-12-18 13:13:29', '2013-01-13 18:35:47', '校长寄语', '       教师的培养和遴选是人才教育的重要环节，其在接受基础教育期间的品质和学习表现也必然反映在其从事教师职业所需要的品质和学习力方面......', '<p> &nbsp;<img style="float:right;" src="/protected/extensions/ueditor/php/upload/90101358063456.jpg" /> <span style="font-family:simsun;"><br /></span></p><p style="text-indent:32px;"><span style="line-height:150%;font-family:宋体;font-size:16px;">每一位教师一旦走上一线教学工作岗位，教育管理机构就准备了一套定性和定量的职责管理办法，教师们就按照职责要求执行和履行。也许最后的成效不一定令所有的关联者满意，这中间可能有两方面的原因，一方面执课教师有能力但没有行使勤勉义务，一方面执课教师尽职尽责了但教学成效不足。无论是哪方面的情况，都是因为教师本人的问题——前者是教师品德问题，后者是教师能力问题，或许这个教师两者都不具备。</span><span style="line-height:150%;font-size:16px;"></span></p><p style="text-indent:32px;"><span style="line-height:150%;font-family:times new roman;font-size:16px;"> </span></p><p style="text-indent:32px;"><span style="line-height:150%;font-family:宋体;font-size:16px;">教师必须具备怎样的品德和能力，在他们自己准备以教师作为职业之前也把握不准，但教育管理机构会有要求和评判，合者就进来，反之就拒之于门外。当然，在教师没有正式走上工作岗位前，他们还没有通过履行职责而表现出的教学绩效。教育管理机构也不可能允许有意从事教师职业的人直接行使教学职责，教育管理机构只能按照历史经验和一套管理程序来决定对教师的选聘和考核。所以，这就最终归结到教师的职能定性和判断的问题，而教育管理机构如何定性和判断教师的职能，这就要考虑到国家的人才和科技发展战略并结合到社会对教师角色的期待方面去作为。</span><span style="line-height:150%;font-size:16px;"></span></p><p style="text-indent:32px;"><span style="line-height:150%;font-family:宋体;font-size:16px;"> </span></p><p style="text-indent:32px;"><span style="line-height:150%;font-family:宋体;font-size:16px;">每个人在从母胎体呱呱坠地之后，就被置身于一个复杂的社会环境中，任何时代的社会都会使用种种方法对他（她）施加影响，使其成为一个符合该社会要求的成员，使他（她）懂得什么是正确的，是被社会所提倡和鼓励的；什么是错误的，是被禁止与反对的。于此同时，个人也随时随地对当前的社会环境以其自身独特的方式作出种种反应，反作用于环境，从而表现出个人的主观能动性。由此可见，个人的成长与发展就是经历了一系列的社会化的结果。个人成为一个怎样的人，这取决于他的周围环境对他的影响以及他本人对周围环境反作用的行为方式。<span style="color:purple;"></span></span></p><p style="text-indent:32px;"><span style="line-height:150%;font-family:宋体;font-size:16px;"> </span></p><p style="text-indent:32px;"><span style="line-height:150%;font-family:宋体;font-size:16px;">每个孩童一般情况下在三岁时就要进入幼儿园，随后读小学，接后读中学，续后上大学，他（她）一生中差不多接近20年的时间就在学校里学习和生活。而学校的作用，主要是把社会规范、道德的价值观以及历代所积累下来的知识、技能传授给下一代，学生需要通过学习来认知和强化自己的行为，使自己成为一位合乎社会要求和道德判断力的人。不可讳言，学校作用的具体实施者就是教师，而教师的人格、品德、学识、情感等素质直接耳濡目染到自己的学生。“</span><span style="line-height:150%;font-family:宋体;font-size:16px;">一个教师！啊，是多么高尚的人士！……事实上，为了要造就一个人，他本人就应当是作父亲的或者是更有教养的人。——卢梭”</span></p><p style="text-indent:32px;"><span style="line-height:150%;font-family:宋体;font-size:16px;"></span><span style="line-height:150%;font-family:新宋体;font-size:16px;"></span></p><p style="text-indent:32px;"><span style="line-height:150%;font-family:新宋体;font-size:16px;">教师的职能因其所授的教育对象而应该有不同的要求，</span><span style="line-height:150%;font-family:宋体;font-size:16px;">特别是幼儿园教育决定青</span><span style="line-height:150%;font-family:宋体;font-size:16px;">少年性格特点，作为教育管理部门对幼儿园教师的职能定位以及选聘机制应该上升到</span><span style="line-height:150%;font-family:宋体;font-size:16px;">战略地位。</span><span style="line-height:150%;font-family:新宋体;font-size:16px;">“在教师手里操着幼年人的命运，也便操着民族和人类的命运。——陶行</span><span style="line-height:150%;font-family:新宋体;font-size:16px;">知”</span><span style="line-height:150%;font-family:宋体;font-size:16px;">而其他教师群体的职能定位以及选聘机制则有不同的侧重点。不过作为整个教师</span><span style="line-height:150%;font-family:宋体;font-size:16px;">群体的职业要求来说，都有最基本的要求。正如皮亚杰论及——“</span><span style="line-height:150%;font-family:新宋体;font-size:16px;">有关教育与教学的</span><span style="line-height:150%;font-family:新宋体;font-size:16px;">问题中，没有一个问题不总是和师资培养的问题有联系的。如果得不到足够数量合格的教师，任何最使人钦佩的改革也势必要在实践中失败。”而教师的品德和人格是成为合格教师的根本和必要条件。</span><span style="line-height:150%;font-family:新宋体;font-size:16px;">“因为道德是做人的根本。根本一坏，纵然使你有一些学问和本领，也无甚用处。——陶行知”；“教师的人格就是教育工作者的一切，只有健康的心灵才有健康的行为。——乌申斯基”<strong><span style="color:blue;"> </span></strong>；“要把学生造就成一种什么人，自己就应当是什么人。——车尔尼雪夫斯基”人的道德水准影响一个人做事的动机。在正确方向指引下，动机强烈，则其行为越具有积极的社会意义；否则，方向不符合社会要求，动机越强烈，其行为对于社会带来的消极意义越大。可见教师的人格和品德对于学生的重要性。</span></p><p style="text-indent:32px;"><span style="line-height:150%;font-family:宋体;font-size:16px;"></span></p><p style="text-indent:32px;"><span style="line-height:150%;font-family:宋体;font-size:16px;">幼儿教师或小学教师重在其品贤和人格的可塑性，而学历仅局限于适当的中专或大专文化程度就足够了；有大范围地掌握教育幼童的教育学及心理学知识和教学技能（包括与时俱进的现代化辅助教学手段）；有表现对幼小学生的人文关怀和爱心，而不是一个保姆或管家角色。在处于幼童阶段的学生面前，教师的行为示范和言传身教作用，对于培养学生的学习习惯和思维以及道德判断力影响深远</span><span style="line-height:150%;font-family:新宋体;font-size:16px;">。</span><span style="line-height:150%;font-family:宋体;font-size:16px;">因为儿童的模仿力很强，教师的榜样在儿童行为中起重要作用，染于苍则苍，染于黄则黄。“</span><span style="line-height:150%;font-family:宋体;font-size:16px;">教人要从小教起。幼儿比如幼苗，必须培养得宜，方能发荣滋长。否则幼年受了损伤，即不夭折，也难成材。所以小学教育是建国之根本，幼稚教育尤为根本之根本。——陶行知”</span><span style="line-height:150%;font-size:16px;"></span></p><p style="text-align:left;text-indent:32px;"><span style="line-height:150%;font-family:新宋体;font-size:16px;"></span> </p><p style="text-align:left;text-indent:32px;"><span style="line-height:150%;font-family:新宋体;font-size:16px;">小学教师或中学教师需要贤能兼备，而学历须局限在大专以上或大学本科文化程度，同时还要有从事教育职业的积极态度与高尚情感，尤其是其中小学阶段在学校或课堂上的道德品质和学习力的表现对其从事教师职业能够提供足够和有说服力的经验和感受。</span><span style="line-height:150%;font-family:宋体;font-size:16px;">“在任何复杂的经验中，早期的经验一般会留存下来，相机进入后期的经验，这样把早期的和后期的经验连成一体，从而使相继发生的事件构成一个连续的经验。——克伯屈”中小学教师要有专业的教育学、心理学以及与教材相关的复合型知识和教学技能（包括与时俱进的现代化辅助教学手段）</span><span style="line-height:150%;font-family:新宋体;font-size:16px;">“要想学生好学，必须先生好学。惟有学而不厌的先生才能教出学而不厌的学生。——陶行知”“谁要是自己还没有发展、培养和教育好，他就不能发展、培养和教育别人。——第斯多惠”“在敢于担当培养一个人的任务以前，自己就必须造就成一个怎样的人和值得推崇的模范。——卢梭”</span></p><p><span style="line-height:150%;font-family:新宋体;font-size:16px;"> </span></p><p style="text-indent:32px;"><span style="line-height:150%;font-family:新宋体;font-size:16px;">“教师工作不仅是一个光荣重要的岗位，而且是一种崇高而愉快的事业。它对国家人才的培养，文化科学教育事业的发展，以及以后一代的成长起着重大作用。——徐特立”</span><span style="line-height:150%;font-family:宋体;font-size:16px;">从以上层面重在分析教师职业的使用价值范畴，而这种使用价值的作用对象就是国家和社会，只不过是通过反映到学生身上的教学成效体现出来的。有使用价值的事物一定有价值，但有价值的事物不一定有使用价值。由于教育和教学的效果不是短期内可以评判并按照某种标准进行恰当的货币量化，就容易导致部分教师作弊或不作为的情况得不到及时的发现和监管，达到“南郭先生”合法化。但当今的教师又被国家和社会赋予了较高的货币量化，即价值的货币化价格，而实际上并没有发挥其国家和社会预期成效的使用价值。一方面教师的收入（货币化价格体现的价值）是按照教师的社会价值和地位承兑支付的，可是另一方面教师对社会的付出和表现令社会失望，即使用价值被稀释或没有正确地发挥出来。</span><span style="line-height:150%;font-size:16px;"></span></p><p style="text-indent:32px;"><span style="line-height:150%;font-family:宋体;font-size:16px;"></span> </p><p style="text-indent:32px;"><span style="line-height:150%;font-family:宋体;font-size:16px;">人的价值是社会价值与自我价值的统一。人的社会价值是指人的行为的社会意义，即对社会的贡献，如果教师对社会的贡献小于所得到的待遇，那么其行为的社会意义就容易遭到诟病，教师自然就不能得到社会的尊重；人的自我价值是指作为客体的社会、他人以及自己的行为对于作为主体的自我需要的尊重与满足，简而言之，即社会对个人的待遇。由于教师的待遇来自于国家财政，不受市场化机制严格影响，个人的正当需要能够轻易得到尊重和满足，也就实现了其人生的自我价值，但考虑到自己所得到的与社会所期望的有一定剪刀差，因此其个人价值的实现不一定会令自己满意。</span><span style="line-height:150%;font-size:16px;"></span></p><p style="text-indent:32px;"><span style="line-height:150%;font-family:宋体;font-size:16px;"></span> </p><p style="text-indent:32px;"><span style="line-height:150%;font-family:宋体;font-size:16px;">人的价值的内在根据是人。人设想自身需要成为怎样的预想类别，是人追求、奋斗的内在动因。如果准备做教师的人不是发自内心的兴趣而喜欢教师这项职业，或许只希望通过教师职业作为跳板，那么这样的教师也很难在教师岗位上达到某种成就。没有成就的教师，其使用价值自然而然也就被糟蹋了。即使他（她）得到了需要的货币报偿，但其使用价值不能按照社会的预期有效地发挥，那么其价值也就必然缩水，因此他（她）本人也就背离了价值和使用价值的对立统一规律而必须遭到社会的唾骂和非议。</span><span style="line-height:150%;font-size:16px;"></span></p><p style="text-indent:32px;"><span style="line-height:150%;font-family:times new roman;font-size:16px;"> </span></p><p style="text-indent:32px;"><span style="line-height:150%;font-family:宋体;font-size:16px;">任何个人从社会得到的待遇，都要以他（她）对社会的贡献为前提和先决条件。只有作出贡献，才能得到相应的肯定和报偿。对于一个准备作教师的人来说，如果你的动机强烈而希望从事教育事业，那么你就通过以一定的精神和技能献身于你喜欢的工作中去。歌德说过，“你若要喜爱你自己的价值，你就得给世界创造价值。”如果离开了对社会的贡献而侈谈个人的自我价值，只能是海市蜃楼的幻景，而且往往成为贪婪地向社会索取的一种借口。如果仅仅爱好教师职业而不落实到行动上，那无异于叶公好龙。不仅浪费社会资源和国家财政支项，而且可能会贻害你所授教育的学生。当下的很多教师不务正业，只讲索取而做不出令社会所预期的成绩，即使有成绩也是以牺牲学生和学生家长的时间、身体、金钱为代价，缺乏社会效率。</span><span style="font-family:simsun;"> </span></p>', '温瑞征', 1, 0, 0, 26),
(5, NULL, NULL, '高中录取分数线', 1, -1, 1, 0, '2012-12-18 13:52:09', '2012-12-18 13:52:09', '公示公告', '一、我校初中毕业学生录取线93分及以上，奖学金线在学校查询；二、非本校初中毕业生660分及以上（免交学费）；三、凡上线生报名时间为6月29日下午和6月30日上午11点30分前，过期不再录取。成都市实验外国语学校2012年6月29日 ', '<p>一、我校初中毕业学生录取线93分及以上，奖学金线在学校查询；二、非本校初中毕业生660分及以上（免交学费）；三、凡上线生报名时间为6月29日下午和6月30日上午11点30分前，过期不再录取。成都市实验外国语学校2012年6月29日</p>\r\n<p>&nbsp;</p>\r\n<p>一、我校初中毕业学生录取线93分及以上，奖学金线在学校查询；二、非本校初中毕业生660分及以上（免交学费）；三、凡上线生报名时间为6月29日下午和6月30日上午11点30分前，过期不再录取。成都市实验外国语学校2012年6月29日</p>\r\n<p>&nbsp;</p>\r\n<p>一、我校初中毕业学生录取线93分及以上，奖学金线在学校查询；二、非本校初中毕业生660分及以上（免交学费）；三、凡上线生报名时间为6月29日下午和6月30日上午11点30分前，过期不再录取。成都市实验外国语学校2012年6月29日 一、我校初中毕业学生录取线93分及以上，奖学金线在学校查询；二、非本校初中毕业生660分及以上（免交学费）；三、凡上线生报名时间为6月29日下午和6月30日上午11点30分前，过期不再录取。成都市实验外国语学校2012年6月29日</p>', '温瑞征', 1, 0, 0, 3),
(6, NULL, NULL, '成都市实验外国语学校', 1, 68, 1, 0, '2012-12-18 13:59:50', '2012-12-18 13:59:50', '高中录取分数线', '一、我校初中毕业学生录取线93分及以上，奖学金线在学校查询；二、非本校初中毕业生660分及以上（免交学费）；三、凡上线生报名时间为6月29日下午和6月30日上午11点30分前，过期不再录取。成都市实验外国语学校2012年6月29日 ', '<p>一、我校初中毕业学生录取线93分及以上，奖学金线在学校查询；二、非本校初中毕业生660分及以上（免交学费）；三、凡上线生报名时间为6月29日下午和6月30日上午11点30分前，过期不再录取。成都市实验外国语学校2012年6月29日 一、我校初中毕业学生录取线93分及以上，奖学金线在学校查询；二、非本校初中毕业生660分及以上（免交学费）；三、凡上线生报名时间为6月29日下午和6月30日上午11点30分前，过期不再录取。成都市实验外国语学校2012年6月29日</p>', '温瑞征', 1, 0, 0, 0),
(7, NULL, '/images/jsdw/7a283f910d4ac1e20152d5b91e7d4d03.jpg', NULL, 1, 18, 0, 0, '2012-12-26 16:30:53', '2012-12-27 16:42:49', 'asdf', '', '<p class="teacherDetail" style="margin: 0px 10px 5px 0px; padding: 0px 0px 0px 10px; width: 775px; font-size: 18px; border: 0px; overflow: hidden; color: #797979; height: auto; line-height: 32px; text-align: left; text-indent: 36px; font-family: ''Bitstream Charter'', serif, 宋体; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff;">2003年3月，朱镕基正式从国务院总位退休。退休正式从国务院总位退时间都闭门谢客在家读书，不再于公众场合露面。他最,式从国务院总位退不在其位，不谋其政。他甚至还常以&ldquo;一介草民&rdquo;幽默,式从国务院总位退固定在北京居住。他去过上海，去过湖南，也去过广东,式从国务院总位退些地方官员礼节性地来访时，快人快语的朱镕基总是开,式从国务院总位退们发现，退休前后的朱镕基判若两人：退休前，他是个,式从国务院总位退他去过上海，去过湖南，也去过广东。但无些地方官员,式从国务院总位退地来访时，快人快语的朱镕基总是开门见山们发现，退,式从国务院总位退的朱镕基判若两人：退休前，他是个公认的,式从国务院总位退目光，以及他做事果断、大刀阔斧、雷厉风行，又 以及他做事果断、大刀阔斧、雷厉风行，但喜欢同普通人聊天。他看书、练书法、拉胡琴。兴致 以及他做事果断、大刀阔斧、雷厉风行，地来一段京戏。过去的严厉与严肃渐渐淡去，面相温和 以及他做事果断、大刀阔斧、雷厉风行，去医院看眼、看牙时，其人到哪里，笑声就跟到哪里， 以及他做事果断、大刀阔斧、雷厉风行，经常乐成了一团&hellip;&hellip;</p>', 'sdaf', 0, 0, -2, 13),
(8, NULL, NULL, '百度', 1, -1, 1, 0, '2012-12-27 15:58:55', '2012-12-27 15:58:55', '联系我们', '联系我们', '<p><a href="http://cefls/index.php/cate/index?pid=1&amp;cid=17">联系我们</a></p>', '李佳', 1, 0, 0, 14),
(9, NULL, NULL, '百度', 1, -1, 1, 0, '2013-01-02 10:06:22', '2013-01-02 10:06:22', '领导班子', '领导班子', '<div class="middle">\r\n<div class="imginfo"><img src="http://cefls/cefls/images/7.jpg" alt="自坐骑山东省内你的设计是的卡速度快 地方借东风的冲v风格刚刚好" />\r\n<p>自坐骑山东省内你的设计是的卡速度快 地方借东风的冲v风格刚刚好</p>\r\n</div>\r\n<div class="imglist">\r\n<div class="imgitem"><a href="#"><img src="http://cefls/cefls/images/8.jpg" alt="" /></a>\r\n<p><a href="#">副校长：某某某</a></p>\r\n</div>\r\n<div class="imgitem"><a href="#"><img src="http://cefls/cefls/images/8.jpg" alt="" /></a>\r\n<p><a href="#">副校长：某某某</a></p>\r\n</div>\r\n<div class="imgitem"><a href="#"><img src="http://cefls/cefls/images/8.jpg" alt="" /></a>\r\n<p><a href="#">副校长：某某某</a></p>\r\n</div>\r\n<div class="imgitem"><a href="#"><img src="http://cefls/cefls/images/8.jpg" alt="" /></a>\r\n<p><a href="#">副校长：某某某</a></p>\r\n</div>\r\n<div class="imgitem"><a href="#"><img src="http://cefls/cefls/images/8.jpg" alt="" /></a>\r\n<p><a href="#">副校长：某某某</a></p>\r\n</div>\r\n</div>\r\n</div>', '李佳', 1, 0, 0, 0),
(10, NULL, NULL, NULL, 1, 16, 1, 0, '2013-01-08 13:38:16', '2013-01-08 13:38:26', '1', '', '对那些在他们苦难时未离弃他们的忠实朋友，我们应该与他们一样心怀感激；我们从心底里也和他们一样怼怨那些背信弃义乃至伤害、离弃或欺骗他们的叛徒。', NULL, 1, 0, 0, 0),
(11, NULL, NULL, NULL, 1, 16, 1, 0, '2013-01-08 13:39:26', '2013-01-08 13:39:26', '2', '', '成都市实验外国语学校属于成都市乃至四川省内的顶级学校，要成为教育界的影响者和领跑者，而不是模仿者或随从者，因此网站的建设需要引入国际化的元素和创新理念。', NULL, 1, 0, 0, 0),
(12, NULL, NULL, NULL, 1, 16, 1, 0, '2013-01-08 13:39:40', '2013-01-08 13:39:40', '3', '', '成都市实验外国语学校属于成都市乃至四川省内的顶级学校，要成为教育界的影响者和领跑者，而不是模仿者或随从者，因此网站的建设需要引入国际化的元素和创新理念。', NULL, 1, 0, 0, 0),
(13, NULL, NULL, NULL, 1, 16, 1, 0, '2013-01-08 13:39:51', '2013-01-08 13:39:51', '4', '', '成都市实验外国语学校属于成都市乃至四川省内的顶级学校，要成为教育界的影响者和领跑者，而不是模仿者或随从者，因此网站的建设需要引入国际化的元素和创新理念。', NULL, 1, 0, 0, 0),
(14, NULL, NULL, NULL, 1, 16, 1, 0, '2013-01-08 13:40:02', '2013-01-08 13:40:02', '5', '', '成都市实验外国语学校属于成都市乃至四川省内的顶级学校，要成为教育界的影响者和领跑者，而不是模仿者或随从者，因此网站的建设需要引入国际化的元素和创新理念。', NULL, 1, 0, 0, 0),
(15, NULL, NULL, NULL, 1, 16, 1, 0, '2013-01-08 13:40:34', '2013-01-08 13:40:34', '6', '', '关于类似以“德育领地”、“教学科研”、“交流合作”、“外语特色”正名的栏目，其下的二级或三级栏目要尽可能囊括符合栏目概念的内容，如果属于可有可无且不能有效提升学校形象的栏目和内容则最好弃用。有时候什么东西都堆上去，反而是一种累赘。', NULL, 1, 0, 0, 0),
(16, NULL, NULL, NULL, 1, 16, 1, 0, '2013-01-08 13:40:44', '2013-01-08 13:40:44', '7', '', '关于类似以“德育领地”、“教学科研”、“交流合作”、“外语特色”正名的栏目，其下的二级或三级栏目要尽可能囊括符合栏目概念的内容，如果属于可有可无且不能有效提升学校形象的栏目和内容则最好弃用。有时候什么东西都堆上去，反而是一种累赘。', NULL, 1, 0, 0, 0),
(17, NULL, NULL, NULL, 1, 16, 1, 0, '2013-01-08 13:40:56', '2013-01-08 13:40:56', '8', '', '关于类似以“德育领地”、“教学科研”、“交流合作”、“外语特色”正名的栏目，其下的二级或三级栏目要尽可能囊括符合栏目概念的内容，如果属于可有可无且不能有效提升学校形象的栏目和内容则最好弃用。有时候什么东西都堆上去，反而是一种累赘。', NULL, 1, 0, 0, 0),
(18, NULL, NULL, NULL, 1, 16, 1, 0, '2013-01-08 13:42:21', '2013-01-08 13:42:21', '9', '', '关于类似以“德育领地”、“教学科研”、“交流合作”、“外语特色”正名的栏目，其下的二级或三级栏目要尽可能囊括符合栏目概念的内容，如果属于可有可无且不能有效提升学校形象的栏目和内容则最好弃用。有时候什么东西都堆上去，反而是一种累赘。', NULL, 1, 0, 0, 0),
(19, NULL, NULL, NULL, 1, 16, 1, 0, '2013-01-08 13:42:56', '2013-01-08 13:42:56', '10', '', '网站栏目的正名和内容建设工作犹如大型图书馆的管理工作一样，不是简单随意的，否则就会为学校带来负面效应。', NULL, 1, 0, 0, 0),
(20, NULL, NULL, NULL, 1, 16, 1, 0, '2013-01-08 13:43:08', '2013-01-08 13:43:08', '11', '', '网站栏目的正名和内容建设工作犹如大型图书馆的管理工作一样，不是简单随意的，否则就会为学校带来负面效应。', NULL, 1, 0, 0, 0),
(21, NULL, NULL, NULL, 1, 16, 1, 0, '2013-01-08 13:43:20', '2013-01-08 13:43:20', '12', '', '网站栏目的正名和内容建设工作犹如大型图书馆的管理工作一样，不是简单随意的，否则就会为学校带来负面效应。', NULL, 1, 0, 0, 0),
(22, NULL, NULL, '校长办公室', 1, -1, 1, 0, '2013-01-08 17:05:49', '2013-01-13 16:00:43', '实外概况', '实外概况', '<p style="text-align:left;line-height:1.75em;"><span style="font-family:helvetica;font-size:large;"> &nbsp; &nbsp; &nbsp; <span style="color:#17365D;font-size:medium;">成都市实验外国语学校（简称‘成都实外’）是四川省成都市教育局直属管辖的外国语特色学校，是四川省内创办时间最早、班级设置规模最大、教育成效最卓著的两所外国语学校之一。成都实外是国家教育部首次简选载册的23所合格外国语学校之一；作为中国西部外国语学校的标杆，成都实外正在统领着新经济时代下的创新教育思想和现代化治校理念。</span></span></p><p style="text-align:left;line-height:1.75em;"><span style="color:#17365D;"> </span></p><p style="text-align:left;line-height:1.75em;"><span style="font-family:helvetica;font-size:large;"><span style="color:#17365D;font-family:helvetica;font-size:large;"> &nbsp; &nbsp; &nbsp; &nbsp;</span><span style="color:#17365D;font-size:medium;">成都实外是在1963年开始创建的成都市第48中学的教学环境基础上改制鼎成的。原成都市第48中学于1993年开始招收外语教学班（这与新东方英语发轫于同一年），经过当任校长温瑞征先生几年的大胆改革和成功探索并最终于1996年正名为成都市实验外国语学校。2002年，纯粹公立性的成都实外在条件成熟的情势下开始改制为民办公助的股份制学校。自此以后的成都实外就在校长温瑞征先生的锐意进取和卓越领导下而矫健地迈入到以出炉四川省和成都市每年的高考状元为习惯性成就的康庄大道上。</span></span></p><p style="text-align:left;"> </p><p style="text-align:left;line-height:1.75em;"><span style="font-family:helvetica;font-size:large;"> &nbsp; &nbsp; &nbsp; <span style="color:#17365D;font-size:medium;">历史的脚步即将跨入2013年，对于经历了半个世纪的沧桑历练和精蕴积淀的成都实外来说，目前的教学环境和教学规模早已不能满足冀望踏入实外殿堂的喁喁学子的求学垂念。鉴于此状，成都市政府和学校董事会已把决定在毗邻成都北湖公园建设一所现代化的森林花园式学校提上了紧锣密鼓的日程要务，新的成都实外将在2013年秋季正式启用毓秀。</span></span></p><p style="text-align:left;line-height:1.75em;"><span style="color:#17365D;"> </span></p><p style="text-align:left;line-height:1.75em;"><span style="font-family:helvetica;font-size:large;"><span style="color:#17365D;font-family:helvetica;font-size:large;"> &nbsp; &nbsp; &nbsp;</span><span style="color:#17365D;font-size:medium;">目前，成都实外有教职工300多位，其中特聘教育专家1位、特级教师和学科带头人30多位、高级教师120多位、省市优秀骨干教师20多位,外籍教师10多位。成都实外的在校初中和高中学生4000多人，接近85个教学班级，全面实行“学校似家”模式的寄宿制社会化管理。</span></span></p><p style="text-align:left;line-height:1.75em;"><span style="color:#17365D;"> </span></p><p style="text-align:left;line-height:1.75em;"><span style="font-family:helvetica;font-size:large;"><span style="color:#17365D;font-family:helvetica;font-size:large;"> &nbsp; &nbsp; &nbsp; </span><span style="color:#17365D;font-size:medium;">众所周知，自从1993年以来，成都实外的初中和高中教育教学成果一直名列成都市前茅，在群雄逐鹿的成都市内遥遥领先。在成都市每年的高考成就面前，成都实外气势如虹凌绝顶，一览众山山为小。尤其是“高考状元”的常态化产生令社会啧啧称赞，也让其他尾随于后的有影响力学校摸不透其中的玄机。成都实外众望所归、万人景仰，这是与校长团队庄严的教育思想和校园文化的建设一脉相承的，而“状元文化”在成都实外所形成的晕轮效应和沉淀的治学磁场已令成都实外在中国西部的名校中独领风骚、浑厚天成。</span></span></p><p style="text-align:left;line-height:1.75em;"><span style="color:#17365D;"> </span></p><p style="text-align:left;line-height:1.75em;"><span style="font-family:helvetica;font-size:large;"> &nbsp; &nbsp; &nbsp; <span style="color:#17365D;font-size:medium;">10几年来，成都实外的精英学子豪夺轻取四川省高考状元的宝座达六届，另外还有2届被推上成都市高考状元的席位。2004年四川省高考文科前10名中，成都实外就执掌5名，并依序囊括前3名，时称的“文科五虎将”为社会各界有口嘉许。2006年四川省文科前15名中，成都实外就据守7名的半壁巴山蜀道；更富有传奇色彩的是，当年的一个班就有11人考入北京大学和清华大学，被新闻媒体界冠誉为“四川文科第一班”。2009年，四川省文科高考状元之桂冠仍被成都实外成功摘取；当年，在全省600分以上的文科高分段中，成都实外几拥十分之一，大有力拔群雄、独占鳌头之势，其中多达16人被北京大学和清华大学录取，而考入香港中文大学、香港大学、上海交通大学、复旦大学、浙江大学、同济大学等全国重点名牌大学的学生亦多达40位。……2011年，成都实外的学子再次盘踞大成都市的“状元金榜”，……由是观之，莫不率皆如此？！成都实外的教育成果不仅实繁有举，而且还斐然成章、丰富多彩。</span></span></p><p style="text-align:left;line-height:1.75em;"><span style="color:#17365D;"> </span></p><p style="text-align:left;line-height:1.75em;"><span style="font-family:helvetica;font-size:large;"><span style="color:#17365D;font-family:helvetica;font-size:large;"> &nbsp; &nbsp; &nbsp;</span><span style="color:#17365D;font-size:medium;"> 成都实外立足于“厚德、博学、勤俭、立业”的治校彝训教育和培养人才，尊重学生的可塑个性，实施人本教育和自然教育。大凡从成都实外考入国内外高等学府的实外学子，其综合能力素质在同校中拔其尤而彰明较著,因此，不少世界级顶端高校已把能够从成都实外点招到出类拔萃的学生作为高校发展的战略手段之一。2010年，北京大学所实施的“中学校长实名推荐制”首次在四川仅确定了三所学校（成都实外、成都七中、绵阳东辰国际）。为了进一步肯定和信赖成都实外在2011年高考中向北京大学作出的郑重承诺，2011年再次向成都实外追加一名2012年待推举的学生，成都实外是北京大学寄予重托厚望的唯一一所四川学校。另外,在清华大学邀请全国300多所中学校长参加清华大学</span></span><span style="font-family:helvetica;font-size:large;"><span style="color:#17365D;font-size:medium;">100周年校庆庆典上，成都实外是唯一一所受邀两位校级领导的中学。</span></span></p><p style="text-align:left;line-height:1.75em;"><span style="color:#17365D;"> </span></p>', '埃德蒙', 1, 0, 0, 48);
INSERT INTO `blog_article` (`aid`, `src`, `file`, `from`, `uid`, `cid`, `audit`, `grade`, `createtime`, `updatetime`, `title`, `excerpt`, `content`, `author`, `enabled`, `sort`, `type`, `clicknumber`) VALUES
(23, NULL, NULL, '校长办公室', 1, -1, 1, 0, '2013-01-08 17:20:43', '2013-01-13 16:13:05', '实外文化', '实外文化', '<p> <span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px;line-height:1.75em;text-indent:28px;mso-char-indent-count:2.0;"><span style="font-family:宋体;mso-bidi-font-size:14px;"><span style="color:#974806;font-size:16px;">成都市实验外国语学校的文化渊源发端于学校开创者及其领导团队的教育思想和人生价值观并烙上学校发展的时代印迹和风俗习惯。随着岁月的洗礼，成都市实验外国语学校的文化已然沉淀为文雅、修养、高尚、精英的气质和魅力，这足以令工作和学习其间的教师和学生受到良好的浸染和陶冶并以新的高度丰富和提炼。</span></span></p><p style="margin:0cm 0cm 0px;line-height:1.75em;text-indent:28px;mso-char-indent-count:2.0;"><span style="font-family:宋体;mso-bidi-font-size:14px;"><span style="font-size:small;"></span></span> </p><p style="margin:0cm 0cm 0px 24px;text-indent:-24px;mso-list:l0 level1 lfo1;" class="MsoNormal"><span style="font-family:黑体;font-size:19px;mso-bidi-font-family:黑体;" lang="EN-US"><span style="color:#7030A0;mso-list:ignore;">一. &nbsp; &nbsp; </span></span><span style="color:#7030A0;font-family:黑体;font-size:19px;">实外“三本”模式</span></p><p style="margin:0cm 0cm 0px 24px;text-indent:-24px;mso-list:l0 level1 lfo1;" class="MsoNormal"><span style="font-family:黑体;font-size:19px;"></span></p><p style="margin:0cm 0cm 0px;text-align:left;line-height:1.75em;text-indent:21px;word-break:break-all;mso-char-indent-count:1.5;mso-pagination:widow-orphan;"><span style="font-size:small;"><span style="color:black;font-family:宋体;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;" lang="EN-US"><span style="color:#974806;font-size:16px;mso-spacerun:yes;"> </span></span><span style="color:#974806;font-family:宋体;font-size:16px;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;">成都市实验外国语学校自创建以来一直致力于建立与教育理念相符合的“实外文化”。以校园为本建设实外标识文化；以学生为本建设实外学子的教育文化；以教师为本建设实外教师的教学科研文化；“三本”文化相互贯通和彼此推动，最终形成以“实外学子”为核心的“状元文化”或“精英文化”价值链体系。</span></span></p><p style="margin:0cm 0cm 0px;text-align:left;line-height:1.75em;text-indent:21px;word-break:break-all;mso-char-indent-count:1.5;mso-pagination:widow-orphan;"><span style="color:#974806;font-size:16px;"> </span></p><p style="margin:0cm 0cm 0px;text-align:left;line-height:1.75em;text-indent:21px;word-break:break-all;mso-char-indent-count:1.5;mso-pagination:widow-orphan;"><span style="font-size:small;"><span style="color:black;font-family:宋体;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;"></span></span><span style="font-size:small;"><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">成都市实验外国语学校在学生对象的选择上力求“有教无类”，但每个学生的生理情</span></span><span style="font-size:small;"><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">况和智力</span></span><span style="font-family:宋体;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;"><span style="color:#974806;font-size:16px;">因素千差万别而必须“因材施教”，尊重学生的个性化选择和潜在能力，成就学生的终身价值和幸福人生。</span></span></p><p style="line-height:1.75em;"><span style="font-family:宋体;font-size:small;"></span><span style="font-size:small;"><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;"> &nbsp; &nbsp;学校坚信，凡是在实外有过一定时段求学经历的学生，在他们未来人生之路上所确立的立言、立德、立业信念必将受惠于实外文化的积极影响。</span></span></p><p><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px 24px;text-indent:-24px;mso-list:l0 level1 lfo1;" class="MsoNormal"><span style="font-family:黑体;font-size:19px;mso-bidi-font-family:黑体;" lang="EN-US"><span style="color:#7030A0;mso-list:ignore;">二. &nbsp; &nbsp; </span></span><span style="color:#7030A0;font-family:黑体;font-size:19px;">实外教育理念</span><span lang="EN-US"><?xml:namespace prefix="o"></?xml:namespace><o:p><span style="color:#7030A0;font-family:calibri;font-size:small;"> </span></o:p></span></p><p style="margin:0cm 0cm 0px 24px;text-indent:-24px;mso-list:l0 level1 lfo1;" class="MsoNormal"><span lang="EN-US"><o:p><span style="font-family:calibri;font-size:small;"></span></o:p></span> </p><p style="margin:0cm 0cm 0px 24px;line-height:1.75em;text-indent:28px;mso-char-indent-count:2.0;"><span style="font-family:宋体;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;"><span style="color:#974806;font-size:16px;">教育理念是学校行动的战略指南，其正确与否主要通过学校培育输出的学生在社会政治和经济领域所呈现的竞争优势而验证；教育理念是否能够有效贯彻执行以及升华发展，完全取决于当任校长的思想和行为。</span></span></p><p style="margin:0cm 0cm 0px 24px;line-height:1.75em;text-indent:28px;mso-char-indent-count:2.0;"><span style="color:#974806;font-size:16px;"> </span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.75em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-family:宋体;mso-bidi-font-family:宋体;" lang="EN-US"><span style="color:#974806;font-size:16px;mso-list:ignore;">★ &nbsp;</span></span><span style="font-size:small;"><strong style="mso-bidi-font-weight:normal;"><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">办学思想：</span></strong><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">以人为本，开发潜能，整体推进，和谐发展。</span></span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.75em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-family:宋体;mso-bidi-font-family:宋体;" lang="EN-US"><span style="color:#974806;font-size:16px;mso-list:ignore;">★ &nbsp;</span></span><span style="font-size:small;"><strong style="mso-bidi-font-weight:normal;"><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">办学目标：</span></strong><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">打造特色鲜明、文理并重、管理规范、质量一流的精品外国语学校。</span></span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.75em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-family:宋体;mso-bidi-font-family:宋体;" lang="EN-US"><span style="color:#974806;font-size:16px;mso-list:ignore;">★ &nbsp;</span></span><span style="font-size:small;"><strong style="mso-bidi-font-weight:normal;"><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">办学特色：</span></strong><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">以中文母语为基础，弘扬民族文化；以数学为重点，突显理科逻辑思维；以外语为特长，培养国际化人才。</span></span></p><p style="margin:0cm 0cm 0px 52px;text-indent:-24px;mso-list:l0 level2 lfo1;" class="MsoNormal"><span style="font-size:small;"><span style="font-family:宋体;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;"> &nbsp; &nbsp; &nbsp; </span></span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.5em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-size:small;"><span style="font-family:宋体;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;"> &nbsp; &nbsp; &nbsp;<span style="font-family:宋体;font-size:14px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;"> </span></span></span><span style="font-family:仿宋;mso-bidi-font-size:14px;"><span style="color:#17365D;font-size:14px;">汉字是中文的表现形式，也是书法艺术创造的对象。汉字是中华民族先民从世界万事万物中提炼出来的文字，充满智慧和神韵，上契天文、下涵地理、中通人文，成为中国人认识自然、组织社会、创造文化的工具。因此，书法与汉字也就同时承担着文化传承的责任和功能。成都市实验外国语学校以汉字为基础弘扬中华文化为使命，以借助各种外语载体向世界友好国家传播中华文化。</span></span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.5em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="color:#17365D;font-size:14px;"> </span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.5em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-family:仿宋;mso-bidi-font-size:14px;"><span style="color:#17365D;font-size:14px;"> &nbsp; &nbsp; &nbsp;意大利的世界著名多产科学巨擘伽俐略有言———数学是上帝用来书写宇宙的文字，而毕达哥拉斯学派更有惊人之语———数学统治宇宙。</span></span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.5em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-size:small;"><span style="color:#17365D;font-family:仿宋;font-size:14px;mso-bidi-font-size:14px;"> &nbsp; &nbsp; &nbsp;</span></span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.5em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-size:small;"><span style="color:#17365D;font-family:仿宋;font-size:14px;mso-bidi-font-size:14px;"> &nbsp; &nbsp; &nbsp;</span><span style="color:#17365D;font-family:仿宋;font-size:14px;mso-bidi-font-size:14px;">在人类历史发展的进程中，数学是其他任何学科的核心基础，也是计算机科学的基石，甚至对于让人聪明睿智的哲学来说，也离不开数学的逻辑慎密性论证和形象思维支持。数学是规律和理论的裁判和主宰者，因规律和假说都要向数学表明自己的主张，然后等待数学的裁判。</span></span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.5em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-size:small;"><span style="color:#17365D;font-family:仿宋;font-size:14px;mso-bidi-font-size:14px;"> &nbsp; &nbsp; &nbsp;</span></span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.5em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-size:small;"><span style="color:#17365D;font-family:仿宋;font-size:14px;mso-bidi-font-size:14px;"> &nbsp; &nbsp; &nbsp;</span></span><span style="font-family:仿宋;mso-bidi-font-size:14px;"><span style="color:#17365D;font-size:14px;">作为以汉语为母语的中国人来说，在通晓掌握中文运用能力的基础上，如果能够再驾驭包括英语、俄语、法语、西班牙语、德语、阿拉伯语、日语等世界主流语言中的一种或几种，那么他（她）就插上了纵横世界外交的理想翅膀。在当今世界呈扁平化的格局下，成都市实验外国语学校把培养具有国际化视野和胸襟的人才作为学生终身立业的制高点。</span></span></p><p><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.75em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-family:宋体;mso-bidi-font-family:宋体;" lang="EN-US"><span style="color:#974806;font-size:16px;mso-list:ignore;">★ &nbsp;</span></span><span style="font-size:small;"><strong style="mso-bidi-font-weight:normal;"><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">培养目标：</span></strong><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">培养综合素质高、学业成绩优，具有民族精神、国际视野的中学生；为国内外高等学校输送外语水平高、各学科均衡发展的高素质学生。</span></span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.75em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-family:宋体;mso-bidi-font-family:宋体;" lang="EN-US"><span style="color:#974806;font-size:16px;mso-list:ignore;">★ &nbsp;</span></span><span style="font-size:small;"><strong style="mso-bidi-font-weight:normal;"><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">校</span><span lang="EN-US"><span style="mso-spacerun:yes;"><span style="color:#974806;font-family:calibri;font-size:16px;"> &nbsp; &nbsp;</span></span></span><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">训：</span></strong><span style="color:#974806;font-family:calibri;font-size:16px;"> </span><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">厚德</span><span lang="EN-US"><span style="mso-spacerun:yes;"><span style="color:#974806;font-family:calibri;font-size:16px;"> &nbsp;</span></span></span><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">博学</span><span lang="EN-US"><span style="mso-spacerun:yes;"><span style="color:#974806;font-family:calibri;font-size:16px;"> &nbsp;</span></span></span><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">勤俭</span><span lang="EN-US"><span style="mso-spacerun:yes;"><span style="color:#974806;font-family:calibri;font-size:16px;"> &nbsp;</span></span></span><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">立业</span></span></p><p style="margin:0cm 0cm 0px 52px;text-indent:-24px;mso-list:l0 level2 lfo1;" class="MsoNormal"><span style="font-size:small;"><span style="font-family:宋体;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;"> &nbsp; &nbsp; &nbsp; </span></span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.5em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-size:small;"><span style="font-family:宋体;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;"> &nbsp; &nbsp; &nbsp; </span></span><span style="font-family:仿宋;"><span style="color:#17365D;font-size:14px;">在成都市实验外国语学校的文化中，“道德”被赋予了特殊的内涵以用来指导人们可以教化向善的思想和可形可塑的端庄行为，认为每个人的道德判断能力的发展除了生理思想成熟因素外，还依赖于智力的发展和社会经验的积累。为此，学校期望全校教师和学生的思想言论和行为举止能够按照社会公共道德的预期标准进行自身修养和作出角色期待，并最终作出明智的独立判断。“厚德”一词中的“厚”字，更多地被诠释了以下几方面的含义：①社会责任心；②宽宏大度；③思想深远庄重，行为雅正崇高；④个性沉稳理性，具有同情心；⑤说话做事具有合宜性。</span></span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.5em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-size:small;"><span style="color:#17365D;font-family:仿宋;font-size:14px;"> &nbsp; &nbsp; &nbsp;</span></span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.5em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-size:small;"><span style="color:#17365D;font-family:仿宋;font-size:14px;"> &nbsp; &nbsp; &nbsp;</span><span style="color:#17365D;font-family:仿宋;font-size:14px;">在成都市实验外国语学校的文化中，“博学”一词作为校训被作出了如下的意涵界定：①凡属在学校工作的教师，要求掌握教育学生和提高课堂教学效率的深广知识和技能，规避那些不利于学生道德判断的知识和行为；②凡属实外的学生，要求有广泛的爱好和兴趣，涉猎系统性的教学知识和有益于自我身心健康成长的课外知识；③要求每位教师和学生向智者学习、向经验学习，掌握终身学习的技能。</span></span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.5em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-size:small;"><span style="color:#17365D;font-family:仿宋;font-size:14px;"> &nbsp; &nbsp; &nbsp;</span></span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.5em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-size:small;"><span style="color:#17365D;font-family:仿宋;font-size:14px;"> &nbsp; &nbsp; &nbsp;</span></span><span style="font-family:仿宋;"><span style="color:#17365D;font-size:14px;">在成都市实验外国语学校的文化中，“勤俭”一词作为校训是基于两方面的举要：①勤俭伦理属于中华传统文化的礼乐遗规，必须发扬光大；②在一定的历史条件下，实外学子家境殷实，且多数被看作父母的掌上明珠，容易使学子滋生养尊处优的心态。正如唐朝诗人李商隐有言“历览前贤国与家，成由勤俭破由奢”。为此，成都市实验外国语学校特别注重培养学生的勤俭节约、勤能补拙、勤能精业、俭以养德的品质，杜绝挥霍浪费、相互攀比浮夸、不学无术而头脑空虚显摆的恶习，让每个实外学子在校期间就彰显出独立生活和工作的潜能。勤俭美德也是保障学子以后建立幸福家庭的必要品质。</span></span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.5em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-size:small;"><span style="color:#17365D;font-family:仿宋;font-size:14px;"> &nbsp; &nbsp; &nbsp;</span></span></p><p style="margin:0cm 0cm 0px 52px;line-height:1.5em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-size:small;"><span style="color:#17365D;font-family:仿宋;font-size:14px;"> &nbsp; &nbsp; &nbsp;</span><span style="color:#17365D;font-family:仿宋;font-size:14px;">在成都市实验外国语学校的文化中，把“立业”作为校训的压轴词是符合马斯诺的需求层次理论的。生理需求，安全需求，社会需求、自尊需求、立言、立德、立业是每个人的自我价值实现的最高需求。立下事业而不是职业，立下社会责任而不是追名逐利为自己。</span></span></p><p style="margin:0cm 0cm 0px 52px;text-indent:-24px;mso-list:l0 level2 lfo1;" class="MsoNormal"><span style="font-size:small;"><span style="font-family:仿宋;"></span></span> </p><p style="margin:0cm 0cm 0px 52px;line-height:1.75em;text-indent:-24px;mso-list:l0 level2 lfo1;"><span style="font-size:small;"><span style="font-family:仿宋;"> &nbsp; &nbsp; &nbsp;</span></span><span style="font-family:宋体;"><span style="color:#974806;font-size:16px;">成都市实验外国语学校的校训可以概括精炼为“品学兼优，兴家立业”八个字，这也</span></span><span style="font-family:宋体;"><span style="font-size:small;"><span style="color:#974806;font-family:宋体;font-size:16px;">与古代儒家知识分子所崇尚的“正心，修身，齐家，治国，平天下”信条如出一辙。“品学”素质对于教师和学生二者不可偏废，而“兴家立业”则是对实外学子的人生发展的期待，同时也寄望每位实外教师家庭幸福，忠诚全民教育事业。</span><span lang="EN-US"><o:p></o:p></span></span></span></p><p style="line-height:1.75em;"><span style="color:#974806;font-size:16px;"> </span></p><p style="margin:0cm 0cm 0px 52px;text-indent:-24px;mso-list:l0 level2 lfo1;" class="MsoNormal"><span style="font-family:宋体;mso-bidi-font-family:宋体;" lang="EN-US"><span style="color:#974806;font-size:16px;mso-list:ignore;">★ &nbsp;</span></span><span style="font-size:small;"><strong style="mso-bidi-font-weight:normal;"><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">校</span><span lang="EN-US"><span style="mso-spacerun:yes;"><span style="color:#974806;font-family:calibri;font-size:16px;"> &nbsp; &nbsp;</span></span></span><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">风：</span></strong><span style="color:#974806;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">学校以育人为本，教师以敬业为乐，学生以成才为志。</span></span></p><p><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px 24px;text-indent:-24px;mso-list:l0 level1 lfo1;" class="MsoNormal"><span style="font-family:黑体;font-size:19px;mso-bidi-font-family:黑体;" lang="EN-US"><span style="color:#7030A0;mso-list:ignore;">三. &nbsp; &nbsp; </span></span><span style="font-family:黑体;font-size:19px;"><span style="color:#7030A0;font-family:黑体;font-size:19px;">实外标识符号</span><span lang="EN-US"><o:p></o:p></span></span></p><p><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px;line-height:1.75em;"><span style="font-size:small;"><span lang="EN-US"><span style="mso-spacerun:yes;"><span style="font-family:calibri;"> &nbsp;<span style="color:#494429;font-family:calibri;font-size:16px;mso-spacerun:yes;"> </span></span></span></span><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">⊙</span><span style="font-family:calibri;"></span><span style="color:#494429;font-family:黑体;font-size:16px;">学校校名及形体</span></span></p><p style="margin:0cm 0cm 0px;line-height:1.75em;"><span style="font-size:small;"><span lang="EN-US"><span style="font-family:calibri;"><span style="color:#494429;font-size:16px;mso-spacerun:yes;"> &nbsp; &nbsp; </span><span style="color:#494429;font-size:16px;mso-spacerun:yes;"> &nbsp; &nbsp;</span></span></span><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">中文校名法定全称为：成都市实验外国语学校</span></span></p><p style="margin:0cm 0cm 0px;line-height:1.75em;"><span style="font-size:small;"><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;"> &nbsp; &nbsp;</span></span><span style="font-size:small;"><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">中文校名简称为：“成都实外”</span><span lang="EN-US"><span style="mso-spacerun:yes;"><span style="color:#494429;font-family:calibri;font-size:16px;"> &nbsp;</span></span></span><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">或“实外”</span><span lang="EN-US"><span style="color:#494429;font-family:calibri;font-size:16px;">,</span></span><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">但必须是在承前启后的关联场合下使用。</span></span></p><p style="margin:0cm 0cm 0px;line-height:1.75em;"><span style="font-size:small;"><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;"> &nbsp; &nbsp;</span></span><span style="font-family:宋体;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;"><span style="font-size:small;"><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">凡是其他任何掐头缀尾而打擦边球的似是而非的名称都与前述名称无关。在其他需要凸显学校名称的地方或环境，校名一般启用由著名书法家</span><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">庹纯双挥毫泼墨的手迹，即</span></span></span></p><p style="text-align:center;"><span style="font-family:宋体;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;"><span style="font-size:small;"><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;"><img style="width:611px;height:100px;float:none;" title="校名.jpg" border="0" hspace="0" vspace="0" src="/protected/extensions/ueditor/php/upload/74901358057500.jpg" width="717" height="94" /></span></span></span></p><p style="margin:0cm 0cm 0px;line-height:1.75em;"><span style="font-family:宋体;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;"><span style="font-size:small;"><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;"></span></span></span> </p><p style="margin:0cm 0cm 0px;line-height:1.75em;"><span style="font-size:small;"><span lang="EN-US"><span style="font-family:calibri;"><span style="color:#494429;font-size:16px;mso-spacerun:yes;"> &nbsp; &nbsp; </span><span style="color:#494429;font-size:16px;mso-spacerun:yes;"> &nbsp; &nbsp;</span></span></span><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">英文校名法定全称为：</span><span style="color:#494429;font-family:;font-size:16px;" lang="EN-US">Chengdu Experimental Foreign LanguagesSchool</span></span></p><p style="margin:0cm 0cm 0px;line-height:1.75em;"><strong><span style="color:#222222;font-size:19px;" lang="EN-US"><span style="font-family:calibri;"><span style="color:#494429;font-size:16px;mso-spacerun:yes;"> &nbsp; &nbsp;</span><span style="color:#494429;font-size:16px;mso-spacerun:yes;"> &nbsp;</span><span style="color:#494429;font-size:16px;mso-spacerun:yes;"> &nbsp; </span></span></span></strong><span style="font-size:small;"><span style="color:#494429;font-family:宋体;font-size:16px;mso-bidi-font-size:14px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;mso-bidi-font-weight:bold;">英文校名规范缩写为：</span><span style="color:#222222;mso-bidi-font-size:14px;mso-bidi-font-weight:bold;" lang="EN-US"><span style="color:#494429;font-family:calibri;font-size:16px;">CEFLS</span></span><span style="color:#494429;font-family:宋体;font-size:16px;mso-bidi-font-size:14px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;mso-bidi-font-weight:bold;">拼读为</span><span style="color:#222222;mso-bidi-font-size:14px;mso-bidi-font-weight:bold;" lang="EN-US"><span style="font-family:calibri;"><span style="color:#494429;font-family:calibri;font-size:16px;mso-bidi-font-size:14px;mso-bidi-font-weight:bold;">[cefls]</span><span style="color:#494429;font-size:16px;mso-spacerun:yes;"> &nbsp; &nbsp; &nbsp; </span></span></span><span style="color:#494429;font-family:宋体;font-size:16px;mso-bidi-font-size:14px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;mso-bidi-font-weight:bold;">或</span><span style="color:#222222;mso-bidi-font-size:14px;mso-bidi-font-weight:bold;" lang="EN-US"><span style="color:#494429;font-family:calibri;font-size:16px;">Cefls </span></span><span style="color:#494429;font-family:宋体;font-size:16px;mso-bidi-font-size:14px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;mso-bidi-font-weight:bold;">拼读为</span><span style="font-family:calibri;"><span style="color:#494429;font-size:16px;mso-bidi-font-size:14px;mso-bidi-font-weight:bold;" lang="EN-US">[cefls]</span></span></span></p><p style="margin:0cm 0cm 0px;line-height:1.75em;"><span style="font-size:small;"><span style="font-family:calibri;"><span style="color:#494429;font-size:16px;mso-bidi-font-size:14px;mso-bidi-font-weight:bold;" lang="EN-US"></span></span></span><span style="font-size:small;"><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">⊙</span><span style="color:#494429;font-family:黑体;font-size:16px;"> 学校网站域名及地址</span><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">：</span><span lang="EN-US"><a href="http://www.cefls.cn/"><span style="color:#494429;font-family:calibri;font-size:16px;">www.cefls.cn</span></a><span style="font-family:calibri;"><span style="color:#494429;font-family:calibri;font-size:16px;"> </span><span style="color:#494429;font-size:16px;mso-spacerun:yes;"> </span></span></span><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">或</span><span lang="EN-US"><span style="font-family:calibri;"><span style="color:#494429;font-family:calibri;font-size:16px;">www.cefls.com</span><span style="color:#494429;font-size:16px;mso-spacerun:yes;"> &nbsp; </span></span></span></span></p><p style="line-height:1.75em;"><span style="font-family:宋体;font-size:small;"></span><span style="font-family:宋体;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;"><span style="color:#494429;font-size:16px;"> &nbsp; &nbsp; 互联网上搜索关键词为：成都实外</span></span></p><p style="line-height:1.75em;"><span style="font-size:small;"><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">⊙ </span><span style="font-family:calibri;"></span><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">学校校徽及意涵</span></span></p><p style="text-align:center;"><span style="font-family:宋体;font-size:small;"><img style="width:204px;height:203px;float:none;" title="标识.jpg" border="0" hspace="0" vspace="0" src="/protected/extensions/ueditor/php/upload/74641357917129.jpg" width="348" height="382" /></span></p><p style="margin:0cm 0cm 0px;" class="MsoNormal"><span lang="EN-US"><span style="mso-spacerun:yes;"><span style="font-family:calibri;font-size:small;"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span></span></span></p><p><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px;" class="MsoNormal"><span style="font-family:宋体;font-size:small;"></span> </p><p style="margin:0cm 0cm 0px;" class="MsoNormal"><span style="font-size:small;"><span lang="EN-US"><span style="mso-spacerun:yes;"><span style="font-family:calibri;"> &nbsp;<span style="color:#494429;font-family:calibri;font-size:16px;mso-spacerun:yes;"> </span></span></span></span><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">⊙</span><span style="font-family:calibri;"></span><span style="font-family:黑体;font-size:16px;"><span style="color:#494429;font-family:黑体;font-size:16px;">学校校歌及韵律</span><span lang="EN-US"><o:p></o:p></span></span></span></p><p><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px;" class="MsoNormal"><span style="font-size:small;"><span lang="EN-US"><span style="mso-spacerun:yes;"><span style="color:#494429;font-family:calibri;font-size:16px;"> &nbsp; &nbsp; </span></span></span><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">诗歌、礼仪、音乐具有重要的社会教化功能，圣人孔子本人的一生就是“兴于《诗》，立于礼，成于乐。”音乐有一种特殊的道德感染力，可以用来熏陶人，引导人，教人向善。然而音乐也有正邪之别，所以精心制作出符合实外文化稳重肃庄的校歌及其韵律，可以达到历届师生“志意得广”，“容貌得庄”，“行列得正”，“进退得齐”。以下就是成都市实验外国语学校的校歌及其韵律：</span></span></p><p><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px;" class="MsoNormal"><span style="font-size:small;"><span style="color:red;font-family:宋体;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">（等待建设中）</span></span></p><p style="margin:0cm 0cm 0px;" class="MsoNormal"><span style="font-size:small;"><span lang="EN-US"><span style="mso-spacerun:yes;"><span style="font-family:calibri;"> &nbsp;<span style="color:#494429;font-family:calibri;font-size:small;mso-spacerun:yes;"> </span></span></span></span></span></p><p style="margin:0cm 0cm 0px;" class="MsoNormal"><span style="font-size:small;"><span lang="EN-US"><span style="mso-spacerun:yes;"><span style="font-family:calibri;"><span style="color:#494429;font-family:calibri;font-size:small;mso-spacerun:yes;"></span></span></span></span><span style="color:#494429;font-family:宋体;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">⊙</span><span style="font-family:calibri;"></span><span style="font-family:黑体;font-size:16px;"><span style="color:#494429;font-family:黑体;font-size:16px;">学校校旗及精神</span><span lang="EN-US"><o:p></o:p></span></span></span></p><p><span style="font-size:small;"><span style="color:red;font-family:宋体;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">（等待建设中）</span><span style="color:red;" lang="EN-US"><o:p></o:p></span></span></p><p><span style="font-size:small;"><span style="color:#494429;font-family:宋体;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;"></span></span> </p><p><span style="font-size:small;"><span style="color:#494429;font-family:宋体;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">⊙</span><span style="font-family:calibri;"></span><span style="color:#494429;font-family:黑体;font-size:16px;">学校建筑及风格 </span></span></p><p><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px;line-height:1.75em;text-indent:14px;mso-char-indent-count:1.0;"><span style="font-size:small;"><span lang="EN-US"><span style="mso-spacerun:yes;"><span style="font-family:calibri;"> &nbsp;<span style="color:#494429;font-family:calibri;font-size:16px;mso-spacerun:yes;"> &nbsp; </span></span></span></span><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">成都市实验外国语学校的建筑已历经</span><span lang="EN-US"><span style="color:#494429;font-family:calibri;font-size:16px;">50</span></span><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">年的风霜岁月磨蚀和</span><span lang="EN-US"><span style="color:#494429;font-family:calibri;font-size:16px;">50</span></span><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">年的师生人文精神沉积，其建筑气质尤显得质朴和灵动。这种校舍特质已超脱了通常意义的纯物理结构而更加数字化、磁力化，它会让任何一位信步其间的访问者和求学的人感受到一种神奇的魔力和内心的宁静，或许钟灵毓秀、人杰地灵而达成了自然和人的完美促进和融合。</span></span></p><p><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px;" class="MsoNormal"><span lang="EN-US"><o:p><span style="font-family:calibri;font-size:small;"> </span></o:p></span><span style="font-size:small;"><span lang="EN-US"><span style="mso-spacerun:yes;"><span style="font-family:calibri;"> </span></span></span><span style="font-family:宋体;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">⊙</span><span style="font-family:calibri;"></span><span style="font-family:黑体;font-size:16px;">学校师生及形象<span lang="EN-US"><o:p></o:p></span></span></span></p><p><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px;line-height:1.75em;"><span style="font-size:small;"><span lang="EN-US"><span style="mso-spacerun:yes;"><span style="font-family:calibri;"> &nbsp;<span style="color:#494429;font-family:calibri;font-size:16px;mso-spacerun:yes;"> &nbsp; &nbsp; </span></span></span></span><span style="color:#494429;font-family:宋体;font-size:16px;mso-ascii-font-family:calibri;mso-hansi-font-family:calibri;">模仿是人类的天性，特别是对处于身心正式发育阶段的在校中学生来说，老师的一颦一笑、一举一动、一言一行都无不影响着他们的心理认知判断。成都市实验外国语学校要求教师和学生端正各自的角色期待，严禁师生言语庸俗化、行为浮荡化、着装奇异化，始终不渝恪守教育环境的庄重肃穆地位。</span></span></p><p> </p><p style="margin:0cm 0cm 0px 24px;text-indent:-24px;mso-list:l0 level1 lfo1;" class="MsoNormal"><span style="font-family:黑体;font-size:19px;mso-bidi-font-family:黑体;" lang="EN-US"><span style="color:#7030A0;mso-list:ignore;">四. &nbsp; &nbsp; </span></span><span style="font-family:黑体;font-size:19px;"><span style="color:#7030A0;font-family:黑体;font-size:19px;">实外学子宣言</span><span lang="EN-US"><o:p></o:p></span></span></p><p><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px 24px;line-height:1.75em;text-indent:28px;mso-char-indent-count:2.0;"><span style="color:black;font-family:宋体;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;"><span style="font-size:small;"><span style="color:black;font-family:宋体;font-size:16px;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;">在校园里，我们代表老师的形象；在社会上，我们代表实外的形象；在国际上，我们代表成都和国家的形象。在任何时候任何地方，我们都要做合格优秀的实外学子和世界公民</span><span lang="EN-US"><span style="color:black;font-family:宋体;font-size:16px;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;">!</span><o:p></o:p></span></span></span></p><p><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px 24px;text-indent:37px;mso-char-indent-count:2.0;" class="MsoNormal"> </p><p style="margin:0cm 0cm 0px 24px;text-indent:-24px;mso-list:l0 level1 lfo1;" class="MsoNormal"><span style="font-family:黑体;font-size:19px;mso-bidi-font-family:黑体;" lang="EN-US"><span style="color:#7030A0;mso-list:ignore;">五. &nbsp; &nbsp; </span></span><span style="font-family:黑体;font-size:19px;"><span style="color:#7030A0;font-family:黑体;font-size:19px;">实外教师教学文化</span><span lang="EN-US"><o:p></o:p></span></span></p><p><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px 24px;" class="MsoNormal"><span style="color:red;font-family:黑体;font-size:19px;">待建中<span lang="EN-US"><o:p></o:p></span></span></p><p><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px 24px;text-indent:-24px;mso-list:l0 level1 lfo1;" class="MsoNormal"><span style="font-family:黑体;font-size:19px;mso-bidi-font-family:黑体;" lang="EN-US"><span style="color:#7030A0;mso-list:ignore;">六. &nbsp; &nbsp; </span></span><span style="font-family:黑体;font-size:19px;"><span style="color:#7030A0;font-family:黑体;font-size:19px;">实外学子教育文化</span><span lang="EN-US"><o:p></o:p></span></span></p><p><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px 24px;text-align:left;word-break:break-all;mso-pagination:widow-orphan;" class="MsoNormal"><span style="color:#222222;font-family:宋体;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;" lang="EN-US"><span style="font-size:small;"><span style="mso-spacerun:yes;"> &nbsp; &nbsp; </span><o:p></o:p></span></span></p><p><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px 24px;text-align:left;line-height:1.75em;word-break:break-all;mso-pagination:widow-orphan;"><span style="font-size:small;"><span style="color:#222222;font-family:宋体;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;" lang="EN-US"><span style="mso-spacerun:yes;"> &nbsp; &nbsp;</span></span><span style="font-family:宋体;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;" lang="EN-US"><span style="color:#974806;font-size:16px;mso-spacerun:yes;"> </span></span><span style="font-family:宋体;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;"><span style="color:#974806;font-family:宋体;font-size:16px;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;">在成都市实验外国语学校，任何一位受教育的学子都能根据其蕴涵的兴趣和潜能路径得到可塑性及可控性培养，最大化挖掘自己的能动性和生理自然属性。这是成批量生产精英学子和高端人才的必要条件，而这又与学校的治理团队和教学名师层层相因的。</span><span lang="EN-US"><o:p></o:p></span></span></span></p><p style="line-height:1.75em;"><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px 24px;text-align:left;line-height:1.75em;text-indent:28px;word-break:break-all;mso-pagination:widow-orphan;"><span style="font-family:宋体;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;"><span style="font-size:small;"><span style="color:#974806;font-family:宋体;font-size:16px;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;">在成都市实验外国语学校，合作与竞争作为驱动机制被任何学子所认同接受，每一位学生都以开放的心态欢迎在学习方面有所帮助的同学，以期并驾齐驱共同进步。当然，任何一位在学习上需要帮助的同学，他（她）也可以随时就近请教身边志同道合者，其成效不逊于部分教师的功能。同学与同学之间相互激励和推动，气氛融洽，关系和谐，而这又有利于提高学生的学习成效。</span><span lang="EN-US"><o:p></o:p></span></span></span></p><p style="line-height:1.75em;"><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px 24px;text-align:left;line-height:1.75em;text-indent:28px;word-break:break-all;mso-pagination:widow-orphan;"><span style="font-family:宋体;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;"><span style="font-size:small;"><span style="color:#974806;font-family:宋体;font-size:16px;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;">在成都市实验外国语学校，学子之间的竞争动力主要反映在广义层面的纵横时空格局上。他们以班级和学校的名义与学校历届的学长或其他势均力敌的同类学校相互竞争。在学校内部，同学之家的竞争主要体现在知识、技能、兴趣等诸多各有所长方面而不是同质化的应试分数方面，每个学生都要有自我的竞争优势和特长，进行自我暗示和推动。</span><span lang="EN-US"><o:p></o:p></span></span></span></p><p style="line-height:1.75em;"><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px 24px;text-align:left;line-height:1.75em;text-indent:28px;word-break:break-all;mso-pagination:widow-orphan;"><span style="font-family:宋体;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;"><span style="font-size:small;"><span style="color:#974806;font-family:宋体;font-size:16px;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;">在成都市实验外国语学校，所教授的知识和技能一切以满足学子未来的兴家立业为出发，点，根据学子的兴趣和潜能引导学子独立思想和做好未来事业的规划，让每位学子摸索和练就出适合自己的学习方法和终身的学习能力，不唯书而为实。学校竭尽所能为每一位到实外的学子搭好能力培养和训练的人生舞台，强化素质思想教育，使每位学子在学成几年后知书达理通情，成为有明确崇高人生理想和目标的人。</span><span lang="EN-US"><o:p></o:p></span></span></span></p><p style="line-height:1.75em;"><span style="font-family:宋体;font-size:small;"></span></p><p style="margin:0cm 0cm 0px 24px;text-align:left;line-height:1.75em;text-indent:28px;word-break:break-all;mso-pagination:widow-orphan;"><span style="font-family:宋体;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;"><span style="font-size:small;"><span style="color:#974806;font-family:宋体;font-size:16px;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;">在成都市实验外国语学校，是璞实归真的教育理念奠定了高端人才培养和输出的战略基调，而这种基调必然汲引着众多关注子女成长的明智家长共振同鸣。在自从学校修炼出炉诞生第一位四川省高考状元后，“精英学子”的批量生产及价值流程已然成型并以磁场感应的物理能量吸附和磁化着更多敏而好学的聪慧少年投奔成都实外。在学校教育理念丰富和深化过程中，每位实外学子将以“精英学子”的身份确认和强化自己的认知角色，即使暂时稍逊一筹，但精英学子之间的相互促进和帮助必然带来满怀豪情和自信心</span><span style="color:#974806;font-size:16px;" lang="EN-US">,</span><span style="color:#974806;font-family:宋体;font-size:16px;mso-bidi-font-size:14px;mso-bidi-font-family:宋体;mso-font-kerning:0px;">也深化了双边关系和同学之间的友谊。</span></span></span></p>', '李扬', 1, 0, 0, 26);
INSERT INTO `blog_article` (`aid`, `src`, `file`, `from`, `uid`, `cid`, `audit`, `grade`, `createtime`, `updatetime`, `title`, `excerpt`, `content`, `author`, `enabled`, `sort`, `type`, `clicknumber`) VALUES
(24, NULL, NULL, '华西都市报', 1, 14, 1, 0, '2013-01-08 17:26:37', '2013-01-08 17:26:37', '关于成立成都市教育思想研究会的复议报告', '媒体', '<p><span style="font-size: medium;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 成都市实验外国语学校的文化渊源发端于学校开创者及其领导团队的教育思想和人生价值观并烙上学校发展的时代印迹和风俗习惯。随着岁月的洗礼，成都市实验外国语学校的文化已然沉淀为文雅、修养、高尚、精英的气质和魅力，这足以令工作和学习其间的教师和学生受到良好的浸染和陶冶并以新的高度丰富和提炼。</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">一.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>实外&ldquo;三本&rdquo;模式</strong></span></p>\r\n<p align="left"><span style="font-size: medium;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 成都市实验外国语学校自创建以来一直致力于建立与教育理念相符合的&ldquo;实外文化&rdquo;。以校园为本建设实外标识文化；以学生为本建设实外学子的教育文化；以教师为本建设实外教师的教学科研文化； &ldquo;三本&rdquo;文化相互贯通和彼此推动，最终形成以&ldquo;实外学子&rdquo;为核心的&ldquo;状元文化&rdquo;或&ldquo;精英文化&rdquo;价值链体系。</span></p>\r\n<p><span style="font-size: medium;">&nbsp;成都市实验外国语学校在学生对象的选择上力求&ldquo;有教无类&rdquo;，但每个学生的生理情况和智力</span><span style="font-size: medium;">因素千差万别而必须&ldquo;因材施教&rdquo;，尊重学生的个性化选择和潜在能力，成就学生的终身价值和幸福人生。</span></p>\r\n<p><span style="font-size: medium;">&nbsp;&nbsp;&nbsp; &nbsp;学校坚信，凡是在实外有过一定时段求学经历的学生，在他们未来人生之路上所确立的立言、立德、立业信念必将受惠于实外文化的积极影响。</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">二.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>实外教育理念</strong></span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">&nbsp;&nbsp;&nbsp;&nbsp; 教育理念是学校行动的战略指南，其正确与否主要通过学校培育输出的学生在社会政治和经济领域所呈现的竞争优势而验证；教育理念是否能够有效贯彻执行以及升华发展，完全取决于当任校长的思想和行为。</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">★&nbsp; <strong>办学思想：</strong>以人为本，开发潜能，整体推进，和谐发展。</span></p>\r\n<p><span style="font-size: medium;">★&nbsp; <strong>办学目标：</strong>打造特色鲜明、文理并重、管理规范、质量一流的精品外国语学校。</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">★&nbsp; <strong>办学特色：</strong>以中文母语为基础，弘扬民族文化；以数学为重点，突显理科逻辑思维；以外语为特长，培养国际化人才。</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">汉字是中文的表现形式，也是书法艺术创造的对象。汉字是中华民族先民从世界万事万物中提炼出来的文字，充满智慧和神韵，上契天文、下涵地理、中通人文，成为中国人认识自然、组织社会、创造文化的工具。因此，书法与汉字也就同时承担着文化传承的责任和功能。成都市实验外国语学校以汉字为基础弘扬中华文化为使命，以借助各种外语载体向世界友好国家传播中华文化。</span></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">意大利的世界著名多产科学巨擘伽俐略有言&mdash;&mdash;&mdash;数学是上帝用来书写宇宙的文字，而毕达哥拉斯学派更有惊人之语&mdash;&mdash;&mdash;数学统治宇宙。</span></p>\r\n<p><span style="font-size: medium;">在人类历史发展的进程中，数学是其他任何学科的核心基础，也是计算机科学的基石，甚至对于让人聪明睿智的哲学来说，也离不开数学的逻辑慎密性论证和形象思维支持。数学是规律和理论的裁判和主宰者，因规律和假说都要向数学表明自己的主张，然后等待数学的裁判。</span></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p><span style="font-size: medium;">作为以汉语为母语的中国人来说，在通晓掌握中文运用能力的基础上，如果能够再驾驭包括英语、俄语、法语、西班牙语、德语、阿拉伯语、日语等世界主流语言中的一种或几种，那么他（她）就插上了纵横世界外交的理想翅膀。在当今世界呈扁平化的格局下，成都市实验外国语学校把培养具有国际化视野和胸襟的人才作为学生终身立业的制高点。</span></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">★&nbsp; <strong>培养目标：</strong>培养综合素质高、学业成绩优，具有民族精神、国际视野的中学生；为国内外高等学校输送外语水平高、各学科均衡发展的高素质学生。</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">★&nbsp; <strong>校&nbsp;&nbsp;&nbsp; </strong><strong>训：</strong> 厚德&nbsp; 博学&nbsp; 勤俭&nbsp; 立业</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">在成都市实验外国语学校的文化中，&ldquo;道德&rdquo;被赋予了特殊的内涵以用来指导人们可以教化向善的思想和可形可塑的端庄行为，认为每个人的道德判断能力的发展除了生理思想成熟因素外，还依赖于智力的发展和社会经验的积累。为此，学校期望全校教师和学生的思想言论和行为举止能够按照社会公共道德的预期标准进行自身修养和作出角色期待，并最终作出明智的独立判断。&ldquo;厚德&rdquo;一词中的&ldquo;厚&rdquo;字，更多地被诠释了以下几方面的含义：①社会责任心；②宽宏大度；③思想深远庄重，行为雅正崇高；④个性沉稳理性，具有同情心；⑤说话做事具有合宜性。</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">在成都市实验外国语学校的文化中，&ldquo;博学&rdquo;一词作为校训被作出了如下的意涵界定：①凡属在学校工作的教师，要求掌握教育学生和提高课堂教学效率的深广知识和技能，规避那些不利于学生道德判断的知识和行为；②凡属实外的学生，要求有广泛的爱好和兴趣，涉猎系统性的教学知识和有益于自我身心健康成长的课外知识；③要求每位教师和学生向智者学习、向经验学习，掌握终身学习的技能。</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">在成都市实验外国语学校的文化中，&ldquo;勤俭&rdquo;一词作为校训是基于两方面的举要：①勤俭伦理属于中华传统文化的礼乐遗规，必须发扬光大；②在一定的历史条件下，实外学子家境殷实，且多数被看作父母的掌上明珠，容易使学子滋生养尊处优的心态。正如唐朝诗人李商隐有言&ldquo;历览前贤国与家，成由勤俭破由奢&rdquo;。为此，成都市实验外国语学校特别注重培养学生的勤俭节约、勤能补拙、勤能精业、俭以养德的品质，杜绝挥霍浪费、相互攀比浮夸、不学无术而头脑空虚显摆的恶习，让每个实外学子在校期间就彰显出独立生活和工作的潜能。勤俭美德也是保障学子以后建立幸福家庭的必要品质。</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">在成都市实验外国语学校的文化中，把&ldquo;立业&rdquo;作为校训的压轴词是符合马斯诺的需求层次理论的。生理需求，安全需求，社会需求、自尊需求、立言、立德、立业是每个人的自我价值实现的最高需求。立下事业而不是职业，立下社会责任而不是追名逐利为自己。</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">成都市实验外国语学校的校训可以概括精炼为&ldquo;品学兼优，兴家立业&rdquo;八个字，这也与古代儒家知识分子所崇尚的&ldquo;正心，修身，齐家，治国，平天下&rdquo;信条如出一辙。&ldquo;品学&rdquo;素质对于教师和学生二者不可偏废，而&ldquo;兴家立业&rdquo;则是对实外学子的人生发展的期待，同时也寄望每位实外教师家庭幸福，忠诚全民教育事业。</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">★&nbsp; <strong>校&nbsp;&nbsp;&nbsp; </strong><strong>风：</strong>学校以育人为本，教师以敬业为乐，学生以成才为志。</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">三.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 实外标识符号</span></p>\r\n<p><span style="font-size: medium;">&nbsp;&nbsp; ⊙ 学校校名及形体</span></p>\r\n<p><span style="font-size: medium;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;中文校名法定全称为：成都市实验外国语学校</span></p>\r\n<p><span style="font-size: medium;">中文校名简称为：&ldquo;成都实外&rdquo;&nbsp; 或&ldquo;实外&rdquo;,但必须是在承前启后的关联场合下使用。</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">凡是其他任何掐头缀尾而打擦边球的似是而非的名称都与前述名称无关。在其他需要凸显学校名称的地方或环境，校名一般启用由著名书法家庹纯双挥毫泼墨的手迹，即</span></p>\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;英文校名法定全称为：Chengdu Experimental Foreign Languages School<strong></strong></span></p>\r\n<p><span style="font-size: medium;"><strong>&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;</strong>英文校名规范缩写为：CEFLS 拼读为[cefls]&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 或Cefls 拼读为[cefls]</span></p>\r\n<p>&nbsp;&nbsp;</p>\r\n<p><span style="font-size: medium;">⊙ 学校网站域名及地址：<a href="http://www.cefls.cn">www.cefls.cn</a> &nbsp;或www.cefls.com&nbsp;&nbsp;</span></p>\r\n<p><span style="font-size: medium;">互联网上搜索关键词为：成都实外</span></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">&nbsp;&nbsp; ⊙ 学校校徽及意涵</span></p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p><span style="font-size: medium;">&hellip;&hellip;&hellip;&hellip;.</span></p>\r\n<p><span style="font-size: medium;">&hellip;&hellip;&hellip;..</span></p>\r\n<p><span style="font-size: medium;">&hellip;&hellip;&hellip;..</span></p>\r\n<p><span style="font-size: medium;">&nbsp;&nbsp; ⊙ 学校校歌及韵律</span></p>\r\n<p><span style="font-size: medium;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 诗歌、礼仪、音乐具有重要的社会教化功能，圣人孔子本人的一生就是&ldquo;兴于《诗》，立于礼，成于乐。&rdquo;音乐有一种特殊的道德感染力，可以用来熏陶人，引导人，教人向善。然而音乐也有正邪之别，所以精心制作出符合实外文化稳重肃庄的校歌及其韵律，可以达到历届师生&ldquo;志意得广&rdquo;，&ldquo;容貌得庄&rdquo;，&ldquo;行列得正&rdquo;，&ldquo;进退得齐&rdquo;。以下就是成都市实验外国语学校的校歌及其韵律：</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">（等待建设中）</span></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">&nbsp;&nbsp; ⊙ 学校校旗及精神</span></p>\r\n<p><span style="font-size: medium;">（等待建设中）</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">&nbsp;⊙ 学校建筑及风格</span></p>\r\n<p><span style="font-size: medium;">&nbsp;&nbsp; 成都市实验外国语学校的建筑已历经50年的风霜岁月磨蚀和50年的师生人文精神沉积，其建筑气质尤显得质朴和灵动。这种校舍特质已超脱了通常意义的纯物理结构而更加数字化、磁力化，它会让任何一位信步其间的访问者和求学的人感受到一种神奇的魔力和内心的宁静，或许钟灵毓秀、人杰地灵而达成了自然和人的完美促进和融合。</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">&nbsp;&nbsp; ⊙ 学校师生及形象</span></p>\r\n<p><span style="font-size: medium;">&nbsp;&nbsp;&nbsp; 模仿是人类的天性，特别是对处于身心正式发育阶段的在校中学生来说，老师的一颦一笑、一举一动、一言一行都无不影响着他们的心理认知判断。成都市实验外国语学校要求教师和学生端正各自的角色期待，严禁师生言语庸俗化、行为浮荡化、着装奇异化，始终不渝恪守教育环境的庄重肃穆地位。</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">四.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 实外学子宣言</span></p>\r\n<p><span style="font-size: medium;">在校园里，我们代表老师的形象；在社会上，我们代表实外的形象；在国际上，我们代表成都和国家的形象。在任何时候任何地方，我们都要做合格优秀的实外学子和世界公民!</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style="font-size: medium;">五.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 实外教师教学文化</span></p>\r\n<p><span style="font-size: medium;">待建中</span></p>\r\n<p><span style="font-size: medium;">六.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 实外学子教育文化</span></p>\r\n<p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p align="left"><span style="font-size: medium;">&nbsp;&nbsp;&nbsp; &nbsp;在成都市实验外国语学校，任何一位受教育的学子都能根据其蕴涵的兴趣和潜能路径得到可塑性及可控性培养，最大化挖掘自己的能动性和生理自然属性。这是成批量生产精英学子和高端人才的必要条件，而这又与学校的治理团队和教学名师层层相因的。</span></p>\r\n<p align="left"><span style="font-size: medium;">在成都市实验外国语学校，合作与竞争作为驱动机制被任何学子所认同接受，每一位学生都以开放的心态欢迎在学习方面有所帮助的同学，以期并驾齐驱共同进步。当然，任何一位在学习上需要帮助的同学，他（她）也可以随时就近请教身边志同道合者，其成效不逊于部分教师的功能。同学与同学之间相互激励和推动，气氛融洽，关系和谐，而这又有利于提高学生的学习成效。</span></p>\r\n<p align="left"><span style="font-size: medium;">在成都市实验外国语学校，学子之间的竞争动力主要反映在广义层面的纵横时空格局上。他们以班级和学校的名义与学校历届的学长或其他势均力敌的同类学校相互竞争。在学校内部，同学之家的竞争主要体现在知识、技能、兴趣等诸多各有所长方面而不是同质化的应试分数方面，每个学生都要有自我的竞争优势和特长，进行自我暗示和推动。</span></p>\r\n<p align="left"><span style="font-size: medium;">在成都市实验外国语学校，所教授的知识和技能一切以满足学子未来的兴家立业为出发，点，根据学子的兴趣和潜能引导学子独立思想和做好未来事业的规划，让每位学子摸索和练就出适合自己的学习方法和终身的学习能力，不唯书而为实。学校竭尽所能为每一位到实外的学子搭好能力培养和训练的人生舞台，强化素质思想教育，使每位学子在学成几年后知书达理通情，成为有明确崇高人生理想和目标的人。</span></p>\r\n<p align="left"><span style="font-size: medium;">在成都市实验外国语学校，是璞实归真的教育理念奠定了高端人才培养和输出的战略基调，而这种基调必然汲引着众多关注子女成长的明智家长共振同鸣。在自从学校修炼出炉诞生第一位四川省高考状元后，&ldquo;精英学子&rdquo;的批量生产及价值流程已然成型并以磁场感应的物理能量吸附和磁化着更多敏而好学的聪慧少年投奔成都实外。在学校教育理念丰富和深化过程中，每位实外学子将以&ldquo;精英学子&rdquo;的身份确认和强化自己的认知角色，即使暂时稍逊一筹，但精英学子之间的相互促进和帮助必然带来满怀豪情和自信心,也深化了双边关系和同学之间的友谊。</span></p>\r\n<p>&nbsp;</p>', '秦明先', 0, 0, -11, 6),
(25, NULL, NULL, 'cc', 1, 66, 1, 0, '2013-01-09 21:16:58', '2013-01-09 21:16:58', 'xccc', 'cc', '<p>c</p>', 'cc', 1, 0, 0, 3),
(37, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 19:16:02', '2013-01-13 19:29:12', '2004年高考年报', '', '<p>2004<br /></p>', '杨星', 0, 0, -14, 2),
(26, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 18:06:51', '2013-01-13 18:18:46', '2004年高考年报', '', '<p>2004</p>', '杨星', 0, 0, -11, 1),
(27, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 18:07:30', '2013-01-13 18:19:13', '2005年高考年报', '', '<p>2005</p>', '杨星', 0, 0, -11, 1),
(28, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 18:08:01', '2013-01-13 18:19:45', '2006年高考年报', '', '<p>2006</p>', '杨星', 0, 0, -11, 1),
(29, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 18:08:35', '2013-01-13 18:20:00', '2007年高考年报', '', '<p>2007</p>', '杨星', 0, 0, -11, 1),
(30, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 18:11:00', '2013-01-13 18:20:16', '2008年高考年报', '', '<p>2008</p>', '李果', 0, 0, -11, 1),
(31, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 18:11:45', '2013-01-13 18:20:33', '2009年高考年报', '', '<p>2009</p>', '张国盛', 0, 0, -11, 1),
(32, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 18:12:36', '2013-01-13 18:20:48', '2010年高考年报', '', '<p>2010</p>', '秦关应', 0, 0, -11, 1),
(33, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 18:13:09', '2013-01-13 18:21:03', '2011年高考年报', '', '<p>2011</p>', '李俊', 0, 0, -11, 1),
(34, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 18:14:09', '2013-01-13 18:21:21', '2012年高考年报', '', '<p>2012</p>', '王颖颖', 0, 0, -11, 2),
(35, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 18:16:43', '2013-01-13 18:21:39', '2013年高考年报', '', '<p>2013</p>', '宋明明', 0, 0, -11, 3),
(36, NULL, NULL, '成都', 1, 53, 1, 0, '2013-01-13 18:31:20', '2013-01-13 18:31:44', '2004', '成都阿士大夫', '<p>成都阿法斯蒂芬<br /></p>', '成都', 0, 0, -11, 3),
(38, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 19:37:13', '2013-01-13 19:38:22', '2004年高考年报', '', '<p>2004</p>', '李俊', 1, 0, -14, 4),
(39, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 19:39:33', '2013-01-13 19:39:33', '2005年高考年报', '', '<p>2005</p>', '王颖颖', 1, 0, -14, 2),
(40, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 19:40:14', '2013-01-13 19:40:14', '2006年高考年报', '', '<p>2006</p>', '杨星', 1, 0, -14, 1),
(41, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 19:41:16', '2013-01-13 19:41:16', '2007年高考年报', '', '<p>2007</p>', '孙子', 1, 0, -14, 1),
(42, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 19:42:39', '2013-01-13 19:42:39', '2008年高考年报', '', '<p>2008</p>', '高天雨', 1, 0, -14, 1),
(43, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 19:43:29', '2013-01-13 19:43:29', '2009年高考年报', '', '<p>2009</p>', '冉步林', 1, 0, -14, 0),
(44, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 19:44:15', '2013-01-13 19:44:15', '2010年高考年报', '', '<p>2010</p>', '江河水', 1, 0, -14, 0),
(45, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 19:45:30', '2013-01-13 19:45:30', '2011年高考年报', '', '<p>2011</p>', '张言', 1, 0, -14, 0),
(46, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 19:46:13', '2013-01-13 19:46:13', '2012年高考年报', '', '<p>2012</p>', '李佳', 1, 0, -14, 1),
(47, NULL, NULL, '校长办公室', 1, 53, 1, 0, '2013-01-13 19:47:14', '2013-01-13 19:47:14', '2013年高考年报', '', '<p>2013</p>', '谷穗', 1, 0, -14, 3),
(48, NULL, '/images/jsdw/18f0b5f17bdc417fdfc5ee8971966301.jpg', NULL, 1, 20, 0, 0, '2013-01-13 19:59:00', '2013-01-13 20:09:50', '英语教师', '', '<p>Lichade Bell</p><p> </p>', 'Lichade Bell', 0, 0, -2, 0),
(49, NULL, '/images/jsdw/aa929acaab6479fa38dee8d7a3c91c34.jpg', NULL, 1, 20, 0, 0, '2013-01-13 20:14:20', '2013-01-13 20:23:58', '英语教师', '', '<p>Lichade Bell</p><p style="text-align:left;text-indent:16px;"><span style="color:black;font-family:新宋体;font-size:16px;">“窈窕淑女，君子好逑”。美人，谁人不爱，谁人不怜，虽说美女标准国际上有定论，然而由于不同国家、不同民族有着独有的特点，更有着对美的不同理解，因此，所谓“环肥燕瘦”“青菜萝卜各有所爱”，不同国家的男人自然会持不同的美女观。</span></p><p style="text-align:left;text-indent:32px;"><strong><span style="color:navy;font-family:黑体;font-size:16px;"> </span></strong></p><p style="margin:0cm 0cm 0px 56px;text-align:left;"><span style="color:navy;font-family:黑体;font-size:16px;">● &nbsp;</span><strong><span style="color:navy;font-family:黑体;font-size:16px;">中国男人眼中的标准美女 眼睛和胸部都要大</span></strong></p><p style="margin:0cm 0cm 0px 32px;text-align:left;"><span style="color:black;font-family:黑体;font-size:16px;"> </span></p><p style="text-align:left;text-indent:32px;"><span style="color:black;font-family:新宋体;font-size:16px;">不管时代有多么不同，美女的类型多么不同，中国男人总的来说喜欢皮肤白皙、红霞纷飞、五官精致玲珑、胸部丰满有弹性、双腿纤长有力度的美女。</span></p><p style="text-align:left;text-indent:32px;"><span style="color:black;font-family:新宋体;font-size:16px;">为此，美女首先得有一双明亮娇媚的大眼睛，所谓明眸流盼、电波忽闪、勾人心魂。</span></p><p style="text-align:left;text-indent:32px;"><span style="color:black;font-family:新宋体;font-size:16px;">而丰腴的胸部则上升为男人青睐美女的第二大标准。朱唇皓齿、手指纤细而柔软、细腰雪肤、红妆粉饰、肢体透香也是非常必要的。</span></p><p style="text-align:left;text-indent:32px;"><span style="color:black;font-family:新宋体;font-size:16px;">为做到这样的美女，无妆胜有妆的妆效，红唇丰度的性感，清香的体味以及修长圆润的小腿必定成为每天的妆扮健美奋斗目标。</span></p><p style="margin:0cm 3px 0px;text-align:left;text-indent:30px;"><strong><span style="color:navy;font-family:新宋体;font-size:16px;"> </span></strong></p><p style="margin:0cm 3px 0px 56px;text-align:left;"><span style="color:navy;font-family:黑体;font-size:16px;">● &nbsp;</span><strong><span style="color:navy;font-family:黑体;font-size:16px;">英国男人眼中的标准美女 必须是会化妆的气质女</span></strong></p><p style="margin:0cm 3px 0px 32px;text-align:left;"><span style="color:black;font-family:黑体;font-size:16px;"> </span></p><p style="margin:0cm 3px 0px;text-align:left;text-indent:30px;"><span style="color:black;font-family:新宋体;font-size:16px;">英国男人持重而谨慎，保持绅士风度是英国男人从小必修的课程，由此也形成了英国男人独特的美女观：看贵重贵妇人式的女人。这样的女人必须做事稳重，既掌握分寸，又不紧不慢，具且有端庄、严肃的气质。</span></p><p style="margin:0cm 3px 0px;text-align:left;text-indent:30px;"><span style="color:black;font-family:新宋体;font-size:16px;">在外表方面，性感和庄重占有同等重要的地位。英国男人眼中的美女必须每天坚持化妆，保持良好的一丝不苟的外部形象。头发必须认真打理。胸部丰满，樱唇美艳，大腿修长较之明眸大眼更加具有诱惑力。</span></p><p style="margin:0cm 3px 0px;text-align:left;text-indent:30px;"><strong><span style="color:navy;font-family:新宋体;font-size:16px;"> </span></strong></p><p style="margin:0cm 3px 0px 56px;text-align:left;"><span style="color:navy;font-family:黑体;font-size:16px;">● &nbsp;</span><strong><span style="color:navy;font-family:黑体;font-size:16px;">法国男人眼中的标准美女 风度和乳沟一样不能少</span></strong></p><p style="margin:0cm 3px 0px 32px;text-align:left;"><span style="color:black;font-family:黑体;font-size:16px;"> </span></p><p style="margin:0cm 3px 0px;text-align:left;text-indent:30px;"><span style="color:black;font-family:新宋体;font-size:16px;">法国男人青睐文雅娇柔、韵味十足的女人。他们眼中的美女必须举止严谨。服装雅致得体，与人交往讲究语言艺术，语调优美有魅力，待人接物有风度。脖子挺直有力度，腰细，胸丰，必要时优雅服饰下昭然若揭的乳沟和坐着时双腿交叉时的性感最能撩动男人的心。</span></p><p style="margin:0cm 3px 0px;text-align:left;text-indent:30px;"><strong><span style="color:navy;font-family:宋体;font-size:16px;"> </span></strong></p><p style="margin:0cm 3px 0px 56px;text-align:left;"><span style="color:navy;font-family:黑体;font-size:16px;">● &nbsp;</span><strong><span style="color:navy;font-family:黑体;font-size:16px;">美国男人眼中的标准美女 丰满肉感有个性</span></strong></p><p style="margin:0cm 3px 0px 32px;text-align:left;"><span style="font-family:黑体;font-size:16px;"> </span></p><p style="margin:0cm 3px 0px;text-align:left;text-indent:30px;"><span style="font-family:新宋体;font-size:16px;">美国人一向推崇个性美。因而，对美国男人来说，一条破旧的牛仔，一双灰黑的运动鞋，加上一双幽蓝的眼睛，黝黑的皮肤、圆润的乳房、滚圆的臀部，就能吸引任何一位美国男人。</span></p><p style="margin:0cm 3px 0px;text-align:left;text-indent:30px;"><span style="font-family:新宋体;font-size:16px;">而在仪表上，美国男人对于女人发型的要求最高，当然，凸现个性仍是最高境界，因此，不管怪诞的发型也好，还是优雅的发型，都有不同的美。</span></p><p style="margin:0cm 3px 0px;text-align:left;text-indent:30px;"><span style="font-family:新宋体;font-size:16px;">与发型相比，唇妆和眼妆次之。嘴唇饱满、性感是首要考虑，眼妆则须表现眼睛的妩媚和明亮。在性情上，须开朗、幽默、风情撩人。</span></p><p style="margin:0cm 3px 0px;text-align:left;text-indent:30px;"><strong><span style="color:navy;font-family:宋体;font-size:16px;"> </span></strong></p><p style="margin:0cm 3px 0px 56px;text-align:left;"><span style="color:navy;font-family:黑体;font-size:16px;"><img style="float:none;" title="猫.jpg" border="0" hspace="0" vspace="0" src="/protected/extensions/ueditor/php/upload/41901358072382.jpg" /></span></p><p style="margin:0cm 3px 0px 56px;text-align:left;"><span style="color:navy;font-family:黑体;font-size:16px;">● &nbsp;</span><strong><span style="color:navy;font-family:黑体;font-size:16px;">非洲男人眼中的标准美女 额头宽脚踝美</span></strong></p><p style="margin:0cm 3px 0px 32px;text-align:left;"><span style="font-family:黑体;font-size:16px;"> </span></p><p style="margin:0cm 3px 0px;text-align:left;text-indent:30px;"><span style="font-family:新宋体;font-size:16px;">在非洲男人眼里，额部较宽、脚跟秀美、小腿和脖子圆润的美女才是实质意义上的美人。</span></p><p style="margin:0cm 3px 0px;text-align:left;text-indent:30px;"><span style="font-family:新宋体;font-size:16px;">除此之外，皮肤的白皙也渐渐顺应时尚的潮流而成为男人心中的美女标准。为了达到这一标准，非洲女人们都在竭尽全力，甚至牺牲身体的健康去适应时尚的需求。</span></p><p style="margin:0cm 3px 0px;text-align:left;text-indent:30px;"><span style="font-family:新宋体;font-size:16px;">看来，要想成为非洲男人眼中的美女，还必须付出一定的代价。</span></p><p style="margin:0cm 3px 0px;text-align:left;text-indent:30px;"><strong><span style="color:navy;font-family:宋体;font-size:16px;"> </span></strong></p><p style="margin:0cm 3px 0px 56px;text-align:left;"><span style="color:navy;font-family:黑体;font-size:16px;">● &nbsp;</span><strong><span style="color:navy;font-family:黑体;font-size:16px;">印度男人眼中的标准美女 眼神要勾魂秀发要丰盈</span></strong></p><p style="margin:0cm 3px 0px 32px;text-align:left;"><span style="font-family:黑体;font-size:16px;"> </span></p><p style="margin:0cm 3px 0px;text-align:left;text-indent:30px;"><span style="font-family:新宋体;font-size:16px;">印度是个出产美女的国家。这里有美女“流水线”，有从5岁就可以受到很好培育的美女培训机构，因而每每世界上有选美活动，印度美女总能骄傲上榜。也难怪印度美女会受人欢迎。那么，印度男人眼里的美女是什么样的呢？</span></p><p style="margin:0cm 3px 0px;text-align:left;text-indent:30px;"><span style="font-family:新宋体;font-size:16px;">首先，气质要高雅，肌肤要完美无瑕。而且明目闪烁，流盼生辉，摄人魂魄。嘴唇丰润而饱满，鼻子直立而挺拔，头发根根如丝也是主要的指标。</span></p><p style="margin:0cm 3px 0px;text-align:left;text-indent:30px;"><span style="font-family:新宋体;font-size:16px;">所以，很多到印度旅游的男人都会有这样的幻想，能遇到一个有着勾魂惊艳、一双褐色神秘妖媚大眼睛的印度美女，也满足一下自己对印度美女的向往之情。</span></p><p style="text-align:left;"><span style="font-family:新宋体;font-size:16px;"> </span></p>', 'Lichade Bell', 1, 0, -2, 3),
(50, NULL, '/images/jsdw/f3be0f0a9dc1445e29164ec5ff240a91.jpg', NULL, 1, 40, 0, 0, '2013-01-13 20:17:10', '2013-01-13 20:17:10', '法语教师', '', '<p><span style="font-family:calibri;">Mary.chalo</span></p><p> </p>', 'Mary.chalo', 1, 0, -12, 5),
(51, NULL, NULL, '组织结构', 1, -1, 1, 0, '2013-01-13 20:28:21', '2013-01-13 20:28:21', '组织结构', '组织结构', '<p>组织结构<br /></p>', '组织结构', 1, 0, 0, 2);

-- --------------------------------------------------------

--
-- 表的结构 `blog_article_foreign`
--

DROP TABLE IF EXISTS `blog_article_foreign`;
CREATE TABLE IF NOT EXISTS `blog_article_foreign` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `cid` int(2) NOT NULL,
  `audit` tinyint(2) NOT NULL,
  `grade` tinyint(1) NOT NULL,
  `createtime` datetime NOT NULL,
  `updatetime` datetime NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `sort` int(8) NOT NULL,
  `type` smallint(2) NOT NULL,
  `title_en` text NOT NULL,
  `excerpt_en` text NOT NULL,
  `content_en` longtext NOT NULL,
  `author_en` varchar(64) DEFAULT NULL,
  `src_en` varchar(255) DEFAULT NULL,
  `file_en` varchar(255) DEFAULT NULL,
  `from_en` varchar(255) DEFAULT NULL,
  `clicknumber_en` int(8) DEFAULT '0',
  `title_fr` text NOT NULL,
  `excerpt_fr` text NOT NULL,
  `content_fr` longtext NOT NULL,
  `author_fr` varchar(64) DEFAULT NULL,
  `src_fr` varchar(255) DEFAULT NULL,
  `file_fr` varchar(255) DEFAULT NULL,
  `from_fr` varchar(255) DEFAULT NULL,
  `clicknumber_fr` int(8) DEFAULT '0',
  `title_de` text NOT NULL,
  `excerpt_de` text NOT NULL,
  `content_de` longtext NOT NULL,
  `author_de` varchar(64) DEFAULT NULL,
  `src_de` varchar(255) DEFAULT NULL,
  `file_de` varchar(255) DEFAULT NULL,
  `from_de` varchar(255) DEFAULT NULL,
  `clicknumber_de` int(8) DEFAULT '0',
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `blog_article_foreign`
--

INSERT INTO `blog_article_foreign` (`aid`, `uid`, `cid`, `audit`, `grade`, `createtime`, `updatetime`, `enabled`, `sort`, `type`, `title_en`, `excerpt_en`, `content_en`, `author_en`, `src_en`, `file_en`, `from_en`, `clicknumber_en`, `title_fr`, `excerpt_fr`, `content_fr`, `author_fr`, `src_fr`, `file_fr`, `from_fr`, `clicknumber_fr`, `title_de`, `excerpt_de`, `content_de`, `author_de`, `src_de`, `file_de`, `from_de`, `clicknumber_de`) VALUES
(1, 1, 0, 1, 0, '2012-12-14 17:04:03', '2012-12-14 17:04:03', 1, 0, 0, 'asdf', 'asdf', '<p>asdf</p>', 'asdf', NULL, NULL, 'asdf', 2, 'asdf', 'asdf', '<p>asdfasdf</p>', 'asdf', NULL, NULL, 'asdf', 1, 'asdfasdf', 'asdfasf', '<p>asdfasdf</p>', 'asdfasdf', NULL, NULL, 'asdfasdf', 1),
(2, 1, 0, 1, 0, '2012-12-14 17:08:12', '2012-12-14 17:08:12', 1, 0, 0, 'asdf', 'dfasdfas', '<p>fasdfasdf</p>', 'fasdfas', NULL, NULL, 'asdfasd', 6, 'asdfasdf', 'fasdf', '<p>afsdasdf</p>', 'fasdfa', NULL, NULL, 'afsdads', 1, 'asdfasdf', 'asdfasdf', '<p>afsdfasdf</p>', 'afdasdf', NULL, NULL, 'asfdasdf', 1),
(3, 1, 3, 1, 0, '2013-01-09 21:52:01', '2013-01-10 13:32:10', 1, 0, 0, ' CEFLS  Profile  ', 'sss', '<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="font-size: medium;">&nbsp;Chengdu Experimental Foreign Languages School&nbsp;&nbsp; is a nationwide famous foreign languages school, one directly under the Chengdu Municipal Education Committee. Located at No.134 Section 1 N. Yihuan Road of Chengdu City. The school covers an area of 60 mu. Founded in 1963, the original Chengdu No.48 Middle School was renamed Chengdu Experimental Foreign Languages School in 1993 with the approval of Sichuan Provincial Education Committee, Chengdu Municipal Education Committee and being registered in the State Education Ministry. CDEFLS, a boarding school, runs small classes in foreign language teaching. Approximately2500 students in over 40 classes study here and a staff of over 200 work here.</span></p>\r\n<div><span style="font-size: medium;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; The school lays emphasis on fostering international talents that are excellent at both arts and science study. The main education objective of CDEFLS is to train international middle school graduates who have excellent academic achievements and all-round comprehensive qualities and who are good at using foreign languages while possessing innovative scientific thoughts. Students are required to be &ldquo; active in thinking, disciplined in behavior, ambitious and innovative&rdquo;</span></div>\r\n<div>&nbsp;</div>\r\n<div><span style="font-size: medium;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CEFLS has made great academic achievements. For years the junior middle school students have ranked first by exam results in Chengdu. 100% of the CDEFLS senior graduates have passed the National College Entrance Examinations, over 90% of whom have successfully been enrolled in key universities. Senior graduates Yu Jinglan and Liu Yangyang ranked first in Sichuan Province respectively in the National College Entrance Examinations in arts in 1999 and in 2000 . In 2002 100% of the senior graduates in arts and 92.5% of those in science were enrolled in key universities. Graduates from CEFLS now study in famous universities home and abroad, including some in Harvard, Yale, Cornell and Oxford. They receive great popularity in these universities for their excellent academic progress, good discipline and especially for their high proficiency in foreign languages. Relevant reports on the school&rsquo;s development and achievements can be found in those media like People&rsquo;s Daily, CCTV, China Education, Chengdu Daily,&nbsp; Sichuan Daily. Southwest Urban Newspaper etc.</span></div>\r\n<div>&nbsp;</div>\r\n<div><span style="font-size: medium;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;The whole staff of the school and all the students are determined to make greater efforts to make a greater success.</span></div>', '', NULL, NULL, '', 0, 'Profil de CEFLS  ', 'ffff', '<p><span style="color: #0000ff; font-size: medium;"><span class="hps">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Chengdu</span> <span class="hps">exp&eacute;rimentale</span> <span class="hps">&Eacute;cole</span> <span class="hps">des langues &eacute;trang&egrave;res</span> <span class="hps atn">(</span><span class="atn">d&eacute;nomm&eacute; &laquo;</span>Chengdu <span class="hps">r&eacute;el&raquo;</span>), Chengdu, Sichuan <span class="hps">Bureau de l''&eacute;ducation</span> <span class="hps">directement</span> <span class="hps">sous la juridiction de</span> <span class="hps">caract&eacute;ristiques</span> <span class="hps">international de l''&eacute;cole</span> <span class="hps">Etudes</span>, fondateur <span class="hps">du Temps</span> <span class="hps">province du Sichuan</span> <span class="hps">classe</span> <span class="hps">plus t&ocirc;t</span> <span class="hps">grand et</span> <span class="hps">d&eacute;finir l''&eacute;chelle</span>, <span class="hps">les deux</span> <span class="hps">plus remarquable</span> <span class="hps">&eacute;cole</span> <span class="hps">d''enseignement</span> <span class="hps">Langue</span> <span class="hps">efficacit&eacute;</span> <span class="hps">des Affaires &eacute;trang&egrave;res</span> <span class="hps">a.</span> <span class="hps">Chengdu</span> <span class="hps">r&eacute;el</span> <span class="hps">en dehors du</span> <span class="hps">Minist&egrave;re de l''Education</span> <span class="hps">pour la premi&egrave;re fois</span> <span class="hps">l''un de</span> <span class="hps">l''&eacute;cole de langue</span> <span class="hps">&eacute;trang&egrave;re</span>; <span class="hps">contient simplement une</span> <span class="hps">s&eacute;lection du</span> <span class="hps">registre 23</span> <span class="hps">qualifi&eacute;s</span> <span class="hps">comme point de rep&egrave;re</span> <span class="hps">de l''ouest de</span> <span class="hps">la Chine</span> <span class="hps">&Eacute;cole de langues</span> <span class="hps">&eacute;trang&egrave;res</span>, Chengdu <span class="hps">r&eacute;elle innovation dans</span> <span class="hps">la nouvelle &egrave;re &eacute;conomique</span> <span class="hps">est</span> <span class="hps">commandant de la</span> <span class="hps">pens&eacute;e &eacute;ducative</span> <span class="hps">et</span> <span class="hps">Zhixiaolinian</span> <span class="hps">moderne.</span></span><br /><span style="color: #0000ff; font-size: medium;"><span class="hps">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Gransing</span> <span class="hps">Chengdu</span> <span class="hps">v&eacute;ritable restructuration</span> <span class="hps">cr&eacute;&eacute;e en 1963</span> <span class="hps">&agrave; Chengdu</span> <span class="hps">48 Environnement</span> <span class="hps">enseignement</span> <span class="hps">secondaire bas&eacute; sur</span>. <span class="hps">Les</span> <span class="hps">originaux</span> <span class="hps">Chengdu</span> <span class="hps">48 &eacute;coles secondaires</span> <span class="hps">en 1993</span> <span class="hps">a commenc&eacute; &agrave; recruter</span> <span class="hps">des cours de langues</span> <span class="hps">&eacute;trang&egrave;res (qui</span> <span class="hps">a v&eacute;ritablement commenc&eacute;</span> <span class="hps">avec le</span> <span class="hps">New</span> <span class="hps">Oriental</span> <span class="hps">anglais</span> <span class="hps">la m&ecirc;me ann&eacute;e)</span>, <span class="hps">apr&egrave;s quand</span> <span class="hps">Recteur</span> <span class="hps">Wenruitang</span> <span class="hps">pr&eacute;l&egrave;vement</span> <span class="hps">M.</span> <span class="hps">ann&eacute;es de</span> <span class="hps">r&eacute;formes audacieuses</span> <span class="hps">et</span> <span class="hps">d''exploration</span> <span class="hps">r&eacute;ussie</span> <span class="hps">et &eacute;ventuellement</span> <span class="hps">le nom</span> <span class="hps">de 1996</span> <span class="hps">Chengdu</span> <span class="hps">exp&eacute;rimentale</span> <span class="hps">&eacute;cole de langues</span> <span class="hps">&eacute;trang&egrave;res</span>. <span class="hps">En 2002</span>, <span class="hps">la situation de</span> <span class="hps">Chengdu</span> <span class="hps">purement</span> <span class="hps">publiques</span> <span class="hps">r&eacute;elles</span> <span class="hps">conditions ext&eacute;rieures</span> <span class="hps">sont r&eacute;unies pour</span> <span class="hps">commencer &agrave;</span> <span class="hps">restructurer les</span> <span class="hps">gens qui travaillent</span> <span class="hps">pour aider</span> <span class="hps">l''&eacute;cole</span> <span class="hps">stock.</span> <span class="hps">Depuis, apr&egrave;s</span> <span class="hps">le vrai</span> <span class="hps">Chengdu</span> <span class="hps">les principes</span> <span class="hps">Wenruitang</span> <span class="hps">pr&eacute;l&egrave;vement</span> <span class="hps">aller de l''avant</span> <span class="hps">et</span> <span class="hps">d''un leadership exceptionnel</span> <span class="hps">de M.</span> <span class="hps">et</span> <span class="hps">vigoureux dans le</span> <span class="hps">chemin large</span> <span class="hps">du</span> <span class="hps">four</span> <span class="hps">examen</span> <span class="hps">annuel</span> <span class="hps">coll&egrave;ge</span> <span class="hps">d''entr&eacute;e</span> <span class="hps">dans</span> <span class="hps">la province du Sichuan</span> <span class="hps">&agrave; Chengdu</span> <span class="hps">et les r&eacute;alisations</span> <span class="hps">habituelles</span>.</span></p>', '', NULL, NULL, '', 0, ' CEFLS  Profil  ', 'xxx', '<p><span id="result_box" style="color: #800000; font-size: medium;" lang="de"><span class="hps">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Chengdu</span> <span class="hps">Experimental</span> <span class="hps">Foreign</span> <span class="hps">Languages</span> <span class="hps atn">​​School (</span><span class="atn">bezeichnet als "</span>Chengdu <span class="hps atn">real ''</span>), Chengdu, Sichuan <span class="hps">Education</span> <span class="hps">Bureau</span> <span class="hps">direkt unter</span> <span class="hps">die Zust&auml;ndigkeit der</span> <span class="hps">International Studies</span> <span class="hps">Schule</span> <span class="hps">Eigenschaften</span>, Gr&uuml;nder <span class="hps">der Zeit</span> <span class="hps">der Provinz Sichuan</span> <span class="hps">fr&uuml;hesten und gr&ouml;&szlig;ten</span> <span class="hps">Klasse</span> <span class="hps">den Ma&szlig;stab</span>, <span class="hps">den beiden</span> <span class="hps">bedeutendsten</span> <span class="hps">p&auml;dagogischen</span> <span class="hps">Wirksamkeit</span> <span class="hps">Foreign</span> <span class="hps">Language School</span> <span class="hps">ein</span>. <span class="hps">Chengdu</span> <span class="hps">echte</span> <span class="hps">au&szlig;erhalb des</span> <span class="hps">Staatsministeriums f&uuml;r Unterricht</span> <span class="hps">zum ersten Mal</span> <span class="hps">eines der</span> <span class="hps">Fremdsprachenschule</span>, <span class="hps">enth&auml;lt lediglich</span> <span class="hps">eine Auswahl der</span> <span class="hps">Register 23</span> <span class="hps">als Benchmark</span> <span class="hps">der westlichen</span> <span class="hps">China Foreign</span> <span class="hps">Language School</span> <span class="hps">qualifiziert ist,</span> <span class="hps">Chengdu</span> <span class="hps">echte Innovation</span> <span class="hps">in der</span> <span class="hps">neuen wirtschaftlichen &Auml;ra</span> <span class="hps">Kommandeur der</span> <span class="hps">p&auml;dagogischen Denkens</span> <span class="hps">und moderne</span> <span class="hps">Zhixiaolinian</span>.<br /><span class="hps">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;Chengdu</span> <span class="hps">wirkliche Umstrukturierung</span> <span class="hps">Gransing</span> <span class="hps">1963 in</span> <span class="hps">Chengdu</span> <span class="hps">erstellt</span> <span class="hps">48</span> <span class="hps">sekund&auml;re</span> <span class="hps">Lernumgebung</span> <span class="hps">basiert.</span> <span class="hps">Die urspr&uuml;nglichen</span> <span class="hps">Chengdu</span> <span class="hps">48</span> <span class="hps">Schulen</span> <span class="hps">im Jahr 1993</span> <span class="hps">begann,</span> <span class="hps">Fremdsprachenunterricht</span> <span class="hps atn">(</span>die ernsthaft <span class="hps">begann mit der</span> <span class="hps">New Oriental</span> <span class="hps">Englisch</span> <span class="hps">im selben Jahr</span>) <span class="hps">rekrutieren</span>, nachdem <span class="hps">beim</span> <span class="hps">Rektor</span> <span class="hps">Wenruitang</span> <span class="hps">Abgabe</span> <span class="hps">Mr.</span> <span class="hps">Jahren</span> <span class="hps">mutige Reformen</span> <span class="hps">und erfolgreiche</span> <span class="hps">Exploration und</span> <span class="hps">schlie&szlig;lich</span> <span class="hps">nennen</span> <span class="hps">die</span> <span class="hps">1996</span> <span class="hps">Chengdu</span> <span class="hps">Experimental</span> <span class="hps">Foreign Language</span> <span class="hps">School.</span> <span class="hps">Im Jahr 2002 sind</span> <span class="hps">die Situation der</span> <span class="hps">rein &ouml;ffentlichen</span> <span class="hps">Chengdu</span> <span class="hps">realen</span> <span class="hps">&auml;u&szlig;eren Bedingungen</span> <span class="hps">reifen</span> <span class="hps">zu starten</span> <span class="hps">Umstrukturierung der</span> <span class="hps">arbeitenden Menschen</span>, eine Bestandsaufnahme <span class="hps">der Schule zu helfen</span>. <span class="hps">Da nach der</span> <span class="hps">Chengdu</span> <span class="hps">real die</span> <span class="hps">Prinzipien</span> <span class="hps">Wenruitang</span> <span class="hps">Abgabe</span> <span class="hps">vor</span> <span class="hps">und hervorragenden</span> <span class="hps">Leitung von Herrn</span> <span class="hps">kr&auml;ftigen</span> <span class="hps">gut</span> <span class="hps">schmieden</span> <span class="hps">in die</span> <span class="hps">breite Stra&szlig;e</span> <span class="hps">von gebackenen</span> <span class="hps">j&auml;hrlichen</span> <span class="hps atn">College-</span>Aufnahmepr&uuml;fung <span class="hps">in der Provinz Sichuan</span> <span class="hps">und Chengdu</span> <span class="hps">gew&ouml;hnlichen</span> <span class="hps">Leistungen.</span></span></p>\r\n<div id="spell-place-holder" style="height: 25px; display: none;">&nbsp;</div>\r\n<div id="gt-res-tools">\r\n<div id="gt-res-tools-l">\r\n<div id="gt-res-select" class="select-button goog-toolbar-button" data-tooltip-align="t,c" data-tooltip="全选">&nbsp;</div>\r\n</div>\r\n</div>', '', NULL, NULL, '', 0);

-- --------------------------------------------------------

--
-- 表的结构 `blog_authassignment`
--

DROP TABLE IF EXISTS `blog_authassignment`;
CREATE TABLE IF NOT EXISTS `blog_authassignment` (
  `itemname` varchar(64) NOT NULL,
  `userid` varchar(64) NOT NULL,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`itemname`,`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `blog_authassignment`
--

INSERT INTO `blog_authassignment` (`itemname`, `userid`, `bizrule`, `data`) VALUES
('Admin', '1', NULL, 'N;'),
('Authenticated', '2', NULL, 'N;');

-- --------------------------------------------------------

--
-- 表的结构 `blog_authitem`
--

DROP TABLE IF EXISTS `blog_authitem`;
CREATE TABLE IF NOT EXISTS `blog_authitem` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `blog_authitem`
--

INSERT INTO `blog_authitem` (`name`, `type`, `description`, `bizrule`, `data`) VALUES
('Admin', 2, NULL, NULL, 'N;'),
('Authenticated', 2, 'Authenticated user', NULL, 'N;'),
('Comment.*', 1, 'Access all comment actions', NULL, 'N;'),
('Comment.Approve', 0, 'Approve comments', NULL, 'N;'),
('Comment.Delete', 0, 'Delete comments', NULL, 'N;'),
('Comment.Update', 0, 'Update comments', NULL, 'N;'),
('CommentAdministration', 1, 'Administration of comments', NULL, 'N;'),
('Editor', 2, 'Editor', NULL, 'N;'),
('Guest', 2, 'Guest user', NULL, 'N;'),
('Post.*', 1, 'Access all post actions', NULL, 'N;'),
('Post.Admin', 0, 'Administer posts', NULL, 'N;'),
('Post.Create', 0, 'Create posts', NULL, 'N;'),
('Post.Delete', 0, 'Delete posts', NULL, 'N;'),
('Post.Update', 0, 'Update posts', NULL, 'N;'),
('Post.View', 0, 'View posts', NULL, 'N;'),
('PostAdministrator', 1, 'Administration of posts', NULL, 'N;'),
('PostUpdateOwn', 0, 'Update own posts', 'return Yii::app()->user->id==$params["userid"];', 'N;');

-- --------------------------------------------------------

--
-- 表的结构 `blog_authitemchild`
--

DROP TABLE IF EXISTS `blog_authitemchild`;
CREATE TABLE IF NOT EXISTS `blog_authitemchild` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `blog_authitemchild`
--

INSERT INTO `blog_authitemchild` (`parent`, `child`) VALUES
('Authenticated', 'CommentUpdateOwn'),
('Authenticated', 'Guest'),
('Authenticated', 'Post.Create'),
('Authenticated', 'PostUpdateOwn'),
('CommentAdministration', 'Comment.*'),
('Editor', 'Authenticated'),
('Editor', 'CommentAdministration'),
('Editor', 'PostAdministrator'),
('Guest', 'Post.View'),
('PostAdministrator', 'Post.*'),
('PostAdministrator', 'Post.Admin'),
('PostAdministrator', 'Post.Create'),
('PostAdministrator', 'Post.Delete'),
('PostAdministrator', 'Post.Update');

-- --------------------------------------------------------

--
-- 表的结构 `blog_comment`
--

DROP TABLE IF EXISTS `blog_comment`;
CREATE TABLE IF NOT EXISTS `blog_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `status` int(11) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `author` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `url` varchar(128) DEFAULT NULL,
  `post_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_comment_post` (`post_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `blog_comment`
--

INSERT INTO `blog_comment` (`id`, `content`, `status`, `create_time`, `author`, `email`, `url`, `post_id`) VALUES
(1, 'This is a test comment.', 2, 1230952187, 'Tester', 'tester@example.com', NULL, 2);

-- --------------------------------------------------------

--
-- 表的结构 `blog_lookup`
--

DROP TABLE IF EXISTS `blog_lookup`;
CREATE TABLE IF NOT EXISTS `blog_lookup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `code` int(11) NOT NULL,
  `type` varchar(128) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `blog_lookup`
--

INSERT INTO `blog_lookup` (`id`, `name`, `code`, `type`, `position`) VALUES
(1, 'Draft', 1, 'PostStatus', 1),
(2, 'Published', 2, 'PostStatus', 2),
(3, 'Archived', 3, 'PostStatus', 3),
(4, 'Pending Approval', 1, 'CommentStatus', 1),
(5, 'Approved', 2, 'CommentStatus', 2);

-- --------------------------------------------------------

--
-- 表的结构 `blog_menu`
--

DROP TABLE IF EXISTS `blog_menu`;
CREATE TABLE IF NOT EXISTS `blog_menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `menu_name` varchar(255) NOT NULL,
  `menu_type` smallint(3) NOT NULL DEFAULT '0',
  `menu_sort` int(4) NOT NULL DEFAULT '0',
  `menu_count` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`menu_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=70 ;

--
-- 转存表中的数据 `blog_menu`
--

INSERT INTO `blog_menu` (`menu_id`, `parent_id`, `menu_name`, `menu_type`, `menu_sort`, `menu_count`) VALUES
(1, 0, '关于实外', 1, 0, 0),
(2, 0, '师资队伍', 1, 0, 0),
(3, 0, '德育视窗', 1, 0, 0),
(4, 0, '教学科研', 1, 0, 0),
(5, 0, '外语特色', 1, 0, 0),
(6, 0, '交流合作', 1, 0, 0),
(7, 0, '学子风采', 1, 0, 0),
(8, 0, '艺体天地', 1, 0, 0),
(9, 0, '感悟实外', 1, 0, 0),
(10, 1, '实外概况', 2, 0, 0),
(11, 1, '实外文化', 2, 0, 0),
(12, 1, '领导班子', 2, 0, 0),
(13, 1, '组织结构', 2, 0, 0),
(14, 1, '媒体关注', 2, 0, 0),
(15, 1, '资证荣誉', 2, 0, 0),
(16, 1, '大事纪要', 2, 0, 0),
(17, 1, '联系我们', 2, 0, 0),
(18, 2, '数学教师', 2, 0, 0),
(19, 2, '语文教师', 2, 0, 0),
(20, 2, '外语教师', 2, 0, 0),
(21, 2, '物理教师', 2, 0, 0),
(22, 2, '化学教师', 2, 0, 0),
(23, 2, '政治教师', 2, 0, 0),
(24, 2, '历史教师', 2, 0, 0),
(25, 2, '地理教师', 2, 0, 0),
(26, 2, '艺体教师', 2, 0, 0),
(27, 2, '生理卫生教师', 2, 0, 0),
(28, 2, '信息技术教师', 2, 0, 0),
(29, 3, '德育管理', 2, 0, 0),
(30, 3, '德育动态', 2, 0, 0),
(31, 3, '团队活动', 2, 0, 0),
(32, 3, '心理教育', 2, 0, 0),
(33, 3, '德育成果', 2, 0, 0),
(34, 4, '学研管理', 2, 0, 0),
(35, 4, '教学动态', 2, 0, 0),
(36, 4, '教研活动', 2, 0, 0),
(37, 4, '课堂延伸', 2, 0, 0),
(38, 4, '教学成果', 2, 0, 0),
(39, 5, '英语课堂', 2, 0, 0),
(40, 5, '外教风采', 2, 0, 0),
(41, 5, '活动集锦', 2, 0, 0),
(42, 5, '法德苑地', 2, 0, 0),
(43, 5, '外语佳作', 2, 0, 0),
(44, 5, '赛事风云', 2, 0, 0),
(45, 5, '学习资源', 2, 0, 0),
(46, 6, '友好学校', 2, 0, 0),
(47, 6, '国内互动', 2, 0, 0),
(48, 6, '国际往来', 2, 0, 0),
(49, 6, '合作项目', 2, 0, 0),
(50, 7, '状元金榜', 2, 0, 0),
(51, 7, '理科精英', 2, 0, 0),
(52, 7, '文科翘楚', 2, 0, 0),
(53, 7, '高考年报', 2, 0, 0),
(54, 8, '运动时空', 2, 0, 0),
(55, 8, '音乐之声', 2, 0, 0),
(56, 8, '美术佳苑', 2, 0, 0),
(57, 9, '学子寄情', 2, 0, 0),
(58, 9, '家长抒怀', 2, 0, 0),
(59, 9, '教师达意', 2, 0, 0),
(60, 9, '媒评舆论', 2, 0, 0),
(61, 0, '实外信箱', -1, 0, 0),
(62, 43, 'English  works', 3, 0, 0),
(63, 43, 'Français  Œuvres', 3, 0, 0),
(64, 43, 'Deutsch Werken', 3, 0, 0),
(65, 0, '友情学校', -1, 0, 0),
(66, 0, '校园快讯', -1, 0, 0),
(67, 0, '校长寄语', -1, 0, 0),
(68, 0, '公示公告', -1, 0, 0),
(69, 0, '敦聘教师', -1, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `blog_post`
--

DROP TABLE IF EXISTS `blog_post`;
CREATE TABLE IF NOT EXISTS `blog_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `content` text NOT NULL,
  `tags` text,
  `status` int(11) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `author_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_post_author` (`author_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `blog_post`
--

INSERT INTO `blog_post` (`id`, `title`, `content`, `tags`, `status`, `create_time`, `update_time`, `author_id`) VALUES
(1, 'Welcome!', 'This blog system is developed using Yii. It is meant to demonstrate how to use Yii to build a complete real-world application. Complete source code may be found in the Yii releases.\r\n\r\nFeel free to try this system by writing new posts and posting comments.', 'yii, blog', 2, 1230952187, 1230952187, 1),
(2, 'A Test Post', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'test', 2, 1230952187, 1230952187, 1),
(3, '阿萨德发生', ' 阿萨德发生的', '2saf', 2, 1354176366, 1354176366, 1);

-- --------------------------------------------------------

--
-- 表的结构 `blog_rights`
--

DROP TABLE IF EXISTS `blog_rights`;
CREATE TABLE IF NOT EXISTS `blog_rights` (
  `itemname` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`itemname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `blog_rights`
--

INSERT INTO `blog_rights` (`itemname`, `type`, `weight`) VALUES
('Authenticated', 2, 1),
('Editor', 2, 0),
('Guest', 2, 2);

-- --------------------------------------------------------

--
-- 表的结构 `blog_tag`
--

DROP TABLE IF EXISTS `blog_tag`;
CREATE TABLE IF NOT EXISTS `blog_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `frequency` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `blog_tag`
--

INSERT INTO `blog_tag` (`id`, `name`, `frequency`) VALUES
(1, 'yii', 1),
(2, 'blog', 1),
(3, 'test', 1),
(4, '2saf', 1);

-- --------------------------------------------------------

--
-- 表的结构 `blog_user`
--

DROP TABLE IF EXISTS `blog_user`;
CREATE TABLE IF NOT EXISTS `blog_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `salt` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `profile` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `blog_user`
--

INSERT INTO `blog_user` (`id`, `username`, `password`, `salt`, `email`, `profile`) VALUES
(1, 'admin', '9401b8c7297832c567ae922cc596a4dd', '28b206548469ce62182048fd9cf91760', 'webmaster@example.com', NULL),
(2, 'demo', '2e5c7db760a33498023813489cfadc0b', '28b206548469ce62182048fd9cf91760', 'webmaster@example.com', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `tbl_article`
--

DROP TABLE IF EXISTS `tbl_article`;
CREATE TABLE IF NOT EXISTS `tbl_article` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `src` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `from` varchar(255) DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `cid` int(2) NOT NULL,
  `audit` tinyint(2) NOT NULL,
  `grade` tinyint(1) NOT NULL,
  `createtime` datetime NOT NULL,
  `updatetime` datetime NOT NULL,
  `title` text NOT NULL,
  `excerpt` text NOT NULL,
  `content` longtext NOT NULL,
  `author` varchar(64) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `sort` int(8) NOT NULL,
  `type` smallint(2) NOT NULL,
  `clicknumber` int(8) DEFAULT '0',
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `tbl_migration`
--

DROP TABLE IF EXISTS `tbl_migration`;
CREATE TABLE IF NOT EXISTS `tbl_migration` (
  `version` varchar(255) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `tbl_migration`
--

INSERT INTO `tbl_migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1353059126),
('m110805_153437_installYiiUser', 1353059159),
('m110810_162301_userTimestampFix', 1353059159);

-- --------------------------------------------------------

--
-- 表的结构 `tbl_profiles`
--

DROP TABLE IF EXISTS `tbl_profiles`;
CREATE TABLE IF NOT EXISTS `tbl_profiles` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `tbl_profiles`
--

INSERT INTO `tbl_profiles` (`user_id`, `first_name`, `last_name`) VALUES
(1, 'Administrator', 'Admin'),
(2, 'xami', 'orzero'),
(3, 'xami', '520');

-- --------------------------------------------------------

--
-- 表的结构 `tbl_profiles_fields`
--

DROP TABLE IF EXISTS `tbl_profiles_fields`;
CREATE TABLE IF NOT EXISTS `tbl_profiles_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `field_type` varchar(50) NOT NULL DEFAULT '',
  `field_size` int(3) NOT NULL DEFAULT '0',
  `field_size_min` int(3) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` text,
  `default` varchar(255) NOT NULL DEFAULT '',
  `widget` varchar(255) NOT NULL DEFAULT '',
  `widgetparams` text,
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `tbl_profiles_fields`
--

INSERT INTO `tbl_profiles_fields` (`id`, `varname`, `title`, `field_type`, `field_size`, `field_size_min`, `required`, `match`, `range`, `error_message`, `other_validator`, `default`, `widget`, `widgetparams`, `position`, `visible`) VALUES
(1, 'first_name', 'First Name', 'VARCHAR', 255, 3, 2, '', '', 'Incorrect First Name (length between 3 and 50 characters).', '', '', '', '', 1, 3),
(2, 'last_name', 'Last Name', 'VARCHAR', 255, 3, 2, '', '', 'Incorrect Last Name (length between 3 and 50 characters).', '', '', '', '', 2, 3);

-- --------------------------------------------------------

--
-- 表的结构 `tbl_users`
--

DROP TABLE IF EXISTS `tbl_users`;
CREATE TABLE IF NOT EXISTS `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(128) NOT NULL DEFAULT '',
  `email` varchar(128) NOT NULL DEFAULT '',
  `activkey` varchar(128) NOT NULL DEFAULT '',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastvisit_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_username` (`username`),
  UNIQUE KEY `user_email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `username`, `password`, `email`, `activkey`, `superuser`, `status`, `create_at`, `lastvisit_at`) VALUES
(1, 'admin', '406319e986398247e47bdcb4d5c59831', 'webmaster@example.com', '669360d2530cbea3b4f4b9119e895bd2', 1, 1, '2012-11-16 09:45:59', '2013-01-13 13:40:18'),
(2, 'xami', '406319e986398247e47bdcb4d5c59831', 'xami520@qq.com', '6a6c20e323d61f476d6461f0d9a14cbd', 0, 0, '2012-11-19 02:34:56', '0000-00-00 00:00:00'),
(3, 'xami520', '406319e986398247e47bdcb4d5c59831', '77765997@qq.com', '56b747a929c639c717fb0f1b81aa6fa5', 0, 0, '2012-11-27 05:33:51', '0000-00-00 00:00:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
